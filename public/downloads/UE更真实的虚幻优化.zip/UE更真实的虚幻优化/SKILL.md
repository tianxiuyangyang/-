---
name: ue-realism-optimization
description: Diagnose and fix "CG 感" in Unreal Engine 5 scenes — procedural interiors and exteriors that look like plastic blocks instead of photographs. Use when a UE scene reads flat, plasticky, "积木感", or when the user asks to make a UE scene 更真实 / 照片级 / photoreal, mentions Gaea/World Creator terrain tools as a fix, or wants an agent to drive the editor over MCP. Covers physical light paths, triplanar PBR, chamfered geometry, book/prop randomization, grime, and the traps that crash or waste days.
metadata:
  short-description: 把 UE 的"积木 CG 感"改成接近照片的写实场景
---

# UE 更真实的虚幻优化

A repeatable pipeline for turning a procedurally-assembled UE scene (engine basic shapes +
constant-colour materials) into something that reads as photographic. Derived from a
15-round real project: a 7000-actor gothic library rebuilt from scratch each iteration.

## When to use

- The scene looks "plastic", "flat", "like a toy", "积木感", "CG 味太重".
- Lights are fake (emissive panels standing in for windows, no sky, no sun direction).
- Materials are constant colours: no albedo/normal/roughness maps anywhere.
- The user proposes terrain tools (Gaea / World Creator) as the realism fix — see
  `references/diagnosis.md#terrain-tools-are-the-wrong-tool` for why that is usually wrong.

## Rule zero: find out what is actually wrong before touching anything

Run the six-point audit in `references/diagnosis.md`. In a typical procedural scene the
ranking is: **lighting > materials > edges > colour/content > grime**. Do not start with
props or post-processing; they cannot rescue a scene where light has no source.

## The pipeline (five passes, in order)

Each pass is a full rebuild. Keep the generator script deterministic (`random.seed(...)`)
so any pass can be re-run and compared.

### 1. Physical light path

- Cut **real openings** in walls instead of gluing emissive quads on a solid box. Build the
  wall as bands + piers around the holes (`A1` in the playbook).
- Add `SkyAtmosphere` + `DirectionalLight` (`atmosphere_sun_light=True`) + `SkyLight`
  (movable, `real_time_capture=True`).
- Replace emissive window material with a **translucent** master (blend mode
  `BLEND_TRANSLUCENT`, two-sided, opacity ~0.4).
- Seal the shell: a second roof skin + a flat deck above it, otherwise sky leaks through
  seams and reads as a broken model.

### 2. Triplanar PBR

- Generate tileable textures offline (numpy + Pillow) — albedo / normal / roughness.
- Master material uses **`WorldAlignedTexture`** so scaled engine cubes get correct texel
  density with **no UV work**. Parameters: `TexAlbedo / TexNormal / TexRough /
  TextureSize / TextureBlend / NormalStrength`.
- Feed `TextureBlend=0` for emissive and metal instances so they keep the flat look.

### 3. Chamfered geometry

- Generate a 100cm chamfered cube as OBJ (24 + 12 + 8 faces) and import as a static mesh.
- Choose mesh per box by size: chamfered for furniture-scale, plain cube for large slabs —
  the chamfer scales with the object, so a wall would otherwise get a pillow edge.

### 4. Content randomization

- Books: per-shelf colour family (3 colours, 55/28/17) + per-shelf height band ±5cm +
  thickness distribution + 5% gaps. This alone removes the "colour chart" look.
- Dust: a few hundred tiny emissive spheres in the light shafts.

### 5. Grime — geometry, not shaders

- Wall-base dust bands, pier-foot collars, floor perimeter darkening: cheap extra boxes
  reusing an existing dark material.
- **Do not** add grime nodes to the master material on weak hardware (see pitfalls).

## Verify with the movie render queue, never with viewport screenshots

Viewport captures include editor gizmos (light-source rectangles, decal arrows) that look
exactly like scene geometry. One full MRQ frame settles every question:

```python
import magiclib_render as r, magiclib_build as mb
r.render([mb.SHOT_PLAN[0]], w=1280, h=720, spatial=1, out_dir=".../Saved/Final")
```

Budget ~50–70 s per 720p frame on integrated graphics; 4 × 1080p ≈ 9 min.

## Pitfalls that cost real days

Read `references/pitfalls.md` in full. The expensive ones:

1. **A material that fails to compile can crash the editor**, not just fall back to default.
   Always build a material standalone, confirm it compiles, *then* rebuild the scene.
2. `MaterialExpressionComponentMask` input pin is `""`, **not** `"Input"`. Same class of bug
   for `Clamp`. Wrong pin names are silently ignored → "Missing input" at compile time.
3. Texture-driven normal maps: scale the height→normal gain down (~0.15–0.35) and blur the
   height first, or the whole scene goes black with sideways normals.
4. `WorldAlignedTexture` `TextureSize` needs `W = 1`; `W = 0` produces ultra-dense stripes.
5. Files executed by the editor's `pyfile` channel must be **UTF-8 without BOM**
   (`SyntaxError: invalid non-printable character U+FEFF`).
6. A file-watch command channel loses commands written **before** the watcher registers —
   wait for the "watcher registered" log line, then touch the file again.

## Hardware sets the ceiling

Integrated GPU (Intel UHD 630, no hardware RT) was measured in this project:

| Effect | Result |
|---|---|
| Lumen `ShortRangeAO` | on/off differs by ~0.35 grey level — useless |
| Master material with 3× WorldAlignedTexture + ~30 nodes | `recompile` hangs for minutes, editor wedges |
| Contact-shadow discs under props | reads as separate grey ellipses — worse than nothing |
| Deferred decal grime | material compiles, nothing renders |

Stop at "high-end CG", not "photograph", unless the machine has a discrete GPU with
hardware ray tracing and the project can take real scanned assets.

## Deliverable shape

- One deterministic generator script (scene rebuild in ~2 min).
- One render script (4 shots).
- A `Saved/STATUS.md` recording decisions **and rejected approaches** — the rejections are
  as valuable as the wins.
- Before/after comparison image.
