# 代码要点（可直接抄）

## A1. 墙体真实开洞

不要用布尔运算，直接把墙拆成"带子 + 柱垛"：

```python
def _side_wall(self, s, material):
    y = s * (HALF_W + WALL_T * 0.5)
    x_lo, x_hi = X0 - WALL_T, X1 + WALL_T
    hole_lo, hole_hi = WIN_Z0 - 8.0, WIN_Z1 + 8.0
    half = WIN_W * 0.5 + 9.0
    holes = [(c - half, c + half) for c in window_centers_x]
    # 下带 / 上带
    self.b(((x_lo+x_hi)*0.5, y, hole_lo*0.5), (x_hi-x_lo, WALL_T, hole_lo), material, "Walls")
    self.b(((x_lo+x_hi)*0.5, y, (hole_hi+Z_TOP)*0.5),
           (x_hi-x_lo, WALL_T, Z_TOP-hole_hi), material, "Walls")
    # 洞与洞之间的柱垛
    edges = [x_lo] + [v for h in holes for v in h] + [x_hi]
    for i in range(0, len(edges), 2):
        a, b = edges[i], edges[i+1]
        if b - a < 1.0:
            continue
        self.b(((a+b)*0.5, y, (hole_lo+hole_hi)*0.5),
               (b-a, WALL_T, hole_hi-hole_lo), material, "Walls")
```

窗内换成半透明玻璃（`BLEND_TRANSLUCENT`、two-sided、Opacity≈0.4），
再把原来的自发光板删掉——否则太阳进不来。

## A2. 天空 / 太阳 / 天光

```python
sky = eas.spawn_actor_from_class(unreal.SkyAtmosphere, V(0, 0, 0))
sun = eas.spawn_actor_from_class(unreal.DirectionalLight, V(0, 0, 1600), R(-14, -60, 0))
comp = sun.get_editor_property("directional_light_component")
comp.set_mobility(unreal.ComponentMobility.MOVABLE)
comp.set_editor_property("atmosphere_sun_light", True)
comp.set_editor_property("intensity", 900.0)        # lux
skl = eas.spawn_actor_from_class(unreal.SkyLight, V(0, 0, 1600))
skc = skl.get_editor_property("sky_light_component")
skc.set_mobility(unreal.ComponentMobility.MOVABLE)
skc.set_editor_property("real_time_capture", True)
skc.set_editor_property("intensity", 1.0)           # 超过 2 就开始发白
```

**强度经验**：太阳 700–900 lux、天光 1.0 是室内甜点；天光拉到 6 会让整屋漂白，
这是排查"画面发灰发白"时第一个要看的参数。

## A3. 三平面 PBR 主材质

用引擎自带的 `WorldAlignedTexture`，一个节点顶掉 30 行 triplanar 手写：

```python
fn = unreal.load_asset("/Engine/Functions/Engine_MaterialFunctions01/Texturing/"
                       "WorldAlignedTexture.WorldAlignedTexture")
call = mel.create_material_expression(m, unreal.MaterialExpressionMaterialFunctionCall, -800, 400)
call.set_editor_property("material_function", fn)
mel.connect_material_expressions(tex_param, "", call, "TextureObject")
mel.connect_material_expressions(size_vector_param, "", call, "TextureSize")
# 输出 pin: "XYZ Texture"
```

参数集：`TexAlbedo / TexNormal / TexRough / TextureSize(向量, W=1) /
TextureBlend / NormalStrength`。

- `TextureBlend = 0` → 完全退回常量色（自发光、金属、玻璃用这个）
- 染色：`BaseColor = 目标色 / 贴图均值`，灰度贴图均值约 0.45
- 法线用 `TextureBlend` 门控：`alpha = NormalStrength * TextureBlend`，
  否则 blend=0 时法线仍然生效，场景会发黑（见 pitfalls #3）

## A4. 生成贴图（离线）

`scripts/gen_textures.py`：numpy + Pillow 生成可平铺的
木纹/石砌/皮革/灰泥，各带 `_D / _N / _R`，1024²。

关键：法线增益 0.15–0.35 + 先模糊；否则见 pitfalls #3。

## A5. 倒角立方体

`scripts/gen_bevel_cube.py`：100cm 立方体、2.5cm 倒角、80 三角面、硬边法线，
导出 OBJ 后 `AssetImportTask` 导入。

按尺寸选网格，避免"枕形边"：

```python
smallest, largest = min(size), max(size)
shape = "cube_b" if smallest <= 140.0 and largest <= 1200.0 else "cube"
```

实测：6679 个 Actor 里 6132 个可以用倒角版。

## A6. 书本分层

```python
fam = random.sample(palette, 3)                 # 每层 3 个色系
fam_w = [0.55, 0.28, 0.17]
band = room * random.uniform(0.72, 0.88)        # 该层统一高度带
bh = max(24.0, min(room - 1.0, band + random.uniform(-5.5, 5.5)))
bw = 3.4..19.0（三档分布）
5% 缺口、0–2.6cm 随机前凸
```

## A7. 浮尘

几百个 0.7–2cm 的微发光球撒在 `z ∈ [180, 1450]`，材质
`BaseColor(1,0.82,0.56) + Emissive 0.55`。

## A8. 几何脏污

- 墙脚：12cm 宽、1.4mm 厚的深色带（两层，贴墙与离墙 20cm 各一条）
- 柱脚：比柱础大一圈的深色方环，6cm 高
- 全部复用已有深色材质 → **零新增着色器变体**

## A9. 出图

```python
r.render(mb.SHOT_PLAN, w=1920, h=1080, spatial=1, out_dir=".../Saved/Final")
```

集成显卡约 50–70 秒/帧（720p），1080p 4 张约 9 分钟。
MRQ 是唯一可信的验收手段（见 pitfalls #7）。
