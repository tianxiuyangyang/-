# 踩坑清单（按代价排序）

每条都在真实项目里发生过，附症状与修法。

## 1. 材质编译失败会让编辑器崩溃，不只是回退默认材质

**症状**：改完 `_make_master()` 直接跑整场景 rebuild → 编辑器进程消失，
`Saved/build_log.txt` 根本没生成，没有任何 build 日志。

**根因**：UE 在构建时会对新材质触发 SM5 shader 编译；节点错连导致的编译错误
在这台机器上直接崩掉编辑器。

**修法（强制流程）**：
1. 先在编辑器里**只建材质**，不进场景：
   ```python
   import magiclib_kit as k
   k._MASTER_PATH = "/Game/Materials/M_MasterVX"   # 或临时改模块变量
   k._make_master()
   ```
2. 日志必须出现 `master material ... built`，且**没有** `Failed to compile`
3. 再用 MCP 调 `MaterialTools.recompile` 二次确认（失败会抛异常）
4. 都通过后才允许 `build`
5. 永远保留上一个能用的 master 版本（`M_MasterV3` 这种命名），出问题把
   `_MASTER_PATH` 指回去 + `build` 即可复原

## 2. 材质节点的 pin 名不是想当然

| 节点 | 错误写法 | 正确写法 |
|---|---|---|
| `MaterialExpressionComponentMask` 输入 | `"Input"` | `""`（空字符串） |
| `MaterialExpressionClamp` 输入 | `"Input"` | 直接别用，用 `1/(1+x²)` 之类的公式绕开 |

错误 pin 名**不会抛异常**，只是连接失败，然后在编译时报
`(Node X) Missing X input`。

## 3. 法线贴图梯度太猛 → 全场景发黑

从高度图算切线空间法线时，如果 `-dH/dx` 直接乘 2–3 倍，高频噪声的梯度会很大，
归一化后法线几乎全部侧向，`N·L` 变负，表面全黑。

**修法**：
- 先对高度图做 2–3 次模糊
- 增益压到 **0.15–0.35**
- 材质里用 `NormalStrength ≈ 0.3`，并用 `TextureBlend` 门控（否则 `blend=0` 时法线仍然生效）

## 4. `WorldAlignedTexture` 的 `TextureSize` 必须给 W = 1

`LinearColor(size, size, size, 0)` 会得到极密的条纹；给 `1.0` 才正常。
这一点在文档里没写，是实测出来的。

## 5. `pyfile` 通道的脚本必须是 UTF-8 **无 BOM**

PowerShell 的 `Set-Content -Encoding UTF8`（PS 5.1）会写 BOM，编辑器执行时报：
```
SyntaxError: invalid non-printable character U+FEFF
```
用 `[System.IO.File]::WriteAllText($p, $s, (New-Object System.Text.UTF8Encoding($false)))`。

## 6. 文件监听式命令通道会丢"启动前"写入的命令

编辑器启动时会把已存在的 `command.txt` 内容记为初始状态，之后只在内容变化时触发。
如果在 watcher 注册前写入，命令会被吞掉。

**修法**：等日志出现 `command watcher registered` 之后再写，且内容要变化
（同样的字符串重复写不一定触发，可先写一个带空格的变体再写正式内容）。

## 7. 视口截图会把 gizmo 当几何

视口抓图里会出现：灯光的方形源、decal 的箭头、相机框。
它们在 **MRQ 真实渲染里不存在**，但在视口抓图里非常像场景物体，
会让人花几小时去"定位那个黄色框"。

**修法**：任何"这是不是场景里的东西"的疑问，都出一帧 MRQ 来判定。

## 8. 假 AO 圆盘比没有更假

给落地物体加近黑圆盘当接触阴影：物体底面是矩形/圆形/异形，圆盘一定会露边，
看起来像"地上多了个灰椭圆"。

**修法**：在软件 Lumen + 基础几何体的组合下放弃这个方案；要做就上顶点色烘焙或 SDF AO。

## 9. Deferred Decal 的投影方向

`DecalActor` 沿组件 **-X** 方向投影。Roll = -90° 是朝上（投到空气里），
要投到地面需要 **+90°**。即使方向对了，贴花域材质若配置不当仍然渲染不出来，
先在视口用一两个 decal 验证，再批量放。

## 10. 组件属性名因引擎版本而异

`StaticMeshActor` 的组件属性在 Python 里通常是 `static_mesh_component`，
但通过 MCP 的 `get_properties` 查时可能报 "property could not be read"。
用 `unreal` Python API（在编辑器内 `pyfile`）比通过 MCP 反射更可靠。

---

## 硬件红线（Intel UHD 630 实测）

| 方案 | 结果 |
|---|---|
| `r.Lumen.ShortRangeAO` 开/关 | 平均差 0.35 灰阶，肉眼不可见 |
| 主材质 3× `WorldAlignedTexture` + 30 节点 | `recompile` 卡死 > 4 分钟，编辑器线程堵死 |
| 圆盘假 AO | 露边，更假 |
| Deferred Decal 污渍 | 材质能建，画面无变化 |

结论：集成显卡 + 无硬件光追的环境，写实上限是"高级 CG"，不是照片。
换独显后这些被否决的方案大多可以重试。
