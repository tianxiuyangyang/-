﻿# -*- coding: utf-8 -*-
"""Generate tileable procedural PBR textures (albedo / normal / roughness) as PNG.

Pure numpy + Pillow, no external assets, so the whole look stays reproducible.
Run:  python gen_textures.py [outdir]
"""
import os
import sys

import numpy as np
from PIL import Image

SIZE = 1024


def _lerp(a, b, t):
    return a + (b - a) * t


def value_noise(n, fx, fy, seed):
    """Tileable bilinear value noise on an n x n grid."""
    rng = np.random.default_rng(seed)
    g = rng.random((fy, fx)).astype(np.float32)
    ys = np.linspace(0, fy, n, endpoint=False, dtype=np.float32)
    xs = np.linspace(0, fx, n, endpoint=False, dtype=np.float32)
    y0 = np.floor(ys).astype(int) % fy
    x0 = np.floor(xs).astype(int) % fx
    y1 = (y0 + 1) % fy
    x1 = (x0 + 1) % fx
    ty = ys - np.floor(ys)
    tx = xs - np.floor(xs)
    ty = ty * ty * (3 - 2 * ty)
    tx = tx * tx * (3 - 2 * tx)
    a = g[np.ix_(y0, x0)]
    b = g[np.ix_(y0, x1)]
    c = g[np.ix_(y1, x0)]
    d = g[np.ix_(y1, x1)]
    top = _lerp(a, b, tx[None, :])
    bot = _lerp(c, d, tx[None, :])
    return _lerp(top, bot, ty[:, None])


def fbm(n, freqs, seed, gain=0.5):
    out = np.zeros((n, n), dtype=np.float32)
    amp, total = 1.0, 0.0
    for i, (fx, fy) in enumerate(freqs):
        out += amp * value_noise(n, fx, fy, seed + i * 977)
        total += amp
        amp *= gain
    return out / total


def height_to_normal(h, strength=0.35):
    dx = np.roll(h, -1, axis=1) - np.roll(h, 1, axis=1)
    dy = np.roll(h, -1, axis=0) - np.roll(h, 1, axis=0)
    nx = -dx * strength
    ny = -dy * strength
    nz = np.ones_like(h)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    nx, ny, nz = nx / ln, ny / ln, nz / ln
    rgb = np.stack([nx * 0.5 + 0.5, ny * 0.5 + 0.5, nz * 0.5 + 0.5], axis=-1)
    return np.clip(rgb, 0, 1)


def save(path, arr, srgb=True):
    a = np.clip(arr, 0, 1)
    if a.ndim == 2:
        a = np.stack([a] * 3, axis=-1)
    img = Image.fromarray((a * 255.0 + 0.5).astype(np.uint8), "RGB")
    img.save(path, optimize=True)
    print("  ", os.path.basename(path))


# --------------------------------------------------------------------------- #
def wood(n=SIZE, seed=11):
    ys = np.linspace(0, 1, n, endpoint=False, dtype=np.float32)[:, None]
    xs = np.linspace(0, 1, n, endpoint=False, dtype=np.float32)[None, :]

    warp = fbm(n, [(4, 4), (8, 8), (16, 16)], seed) * 0.55
    rings = np.sin(2 * np.pi * (ys * 9.0 + warp * 1.4)) * 0.5 + 0.5
    fine = fbm(n, [(8, 64), (16, 128), (32, 256)], seed + 5) * 0.45
    grain = np.clip(rings * 0.55 + fine + 0.22, 0, 1)

    # 4 planks along V with dark grooves and per-plank tone offset
    plank = np.floor(ys * 4.0)
    local = (ys * 4.0) % 1.0
    groove = np.clip(np.minimum(local, 1.0 - local) / 0.035, 0, 1) ** 0.6
    tone = 0.86 + 0.22 * np.sin(plank * 2.7 + 0.4)

    h = grain * groove * 0.9 + 0.1 * groove
    alb = (0.34 + 0.30 * grain) * tone * (0.55 + 0.45 * groove)
    rough = 0.52 + 0.20 * (1.0 - grain) + 0.10 * (1.0 - groove)
    rough = np.broadcast_to(rough, (n, n)) if rough.shape != (n, n) else rough
    return (np.clip(alb, 0, 1), height_to_normal(h, 0.30), np.clip(rough, 0.25, 0.95))


def stone(n=SIZE, seed=23):
    base = fbm(n, [(3, 3), (6, 6), (12, 12), (24, 24)], seed)
    speck = fbm(n, [(64, 64), (128, 128), (256, 256)], seed + 3)

    ys = np.linspace(0, 1, n, endpoint=False, dtype=np.float32)[:, None]
    xs = np.linspace(0, 1, n, endpoint=False, dtype=np.float32)[None, :]
    rows, cols = 4.0, 3.0
    ry = (ys * rows) % 1.0
    rx = (xs * cols + np.floor(ys * rows) * 0.37) % 1.0
    mortar = np.minimum(np.minimum(ry, 1 - ry) / 0.04, np.minimum(rx, 1 - rx) / 0.035)
    mortar = np.clip(mortar, 0, 1) ** 0.5

    h = (base * 0.5 + speck * 0.25 + 0.25) * mortar
    alb = (0.30 + 0.22 * base + 0.10 * speck) * (0.45 + 0.55 * mortar)
    rough = 0.68 - 0.12 * base + 0.18 * (1 - mortar)
    return np.clip(alb, 0, 1), height_to_normal(h, 0.35), np.clip(rough, 0.4, 0.98)


def leather(n=SIZE, seed=37):
    fine = fbm(n, [(32, 32), (64, 64), (128, 128), (256, 256)], seed)
    broad = fbm(n, [(3, 3), (6, 6)], seed + 11)
    h = fine * 0.8 + broad * 0.2
    alb = 0.36 + 0.28 * fine + 0.08 * broad
    rough = 0.55 + 0.22 * (1 - fine)
    return np.clip(alb, 0, 1), height_to_normal(h, 0.18), np.clip(rough, 0.35, 0.9)


def plaster(n=SIZE, seed=53):
    n1 = fbm(n, [(4, 4), (8, 8), (16, 16), (32, 32)], seed)
    n2 = fbm(n, [(64, 64), (128, 128)], seed + 7)
    h = n1 * 0.6 + n2 * 0.4
    alb = 0.55 + 0.18 * n1 + 0.06 * n2
    rough = 0.80 - 0.10 * n1
    return np.clip(alb, 0, 1), height_to_normal(h, 0.15), np.clip(rough, 0.5, 0.98)


def main(outdir):
    os.makedirs(outdir, exist_ok=True)
    for name, fn in (("T_Wood", wood), ("T_Stone", stone),
                     ("T_Leather", leather), ("T_Plaster", plaster)):
        print(name)
        alb, nrm, rgh = fn()
        save(os.path.join(outdir, name + "_D.png"), alb)
        save(os.path.join(outdir, name + "_N.png"), nrm)
        save(os.path.join(outdir, name + "_R.png"), rgh)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else r"E:\魔法图书馆\Content\Textures")
