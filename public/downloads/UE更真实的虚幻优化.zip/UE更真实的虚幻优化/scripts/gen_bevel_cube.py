﻿# -*- coding: utf-8 -*-
"""Emit a 100cm chamfered cube as OBJ (fixed 1.6cm chamfer).

The scene scales this mesh to arbitrary box sizes, so the chamfer scales with
each axis; thin beams get a thin chamfer (correct look), while big slabs keep
using the plain engine cube.
"""
import math
import os

H = 50.0
B = 2.5
UNIT = 100.0


def P(a, s, u_sign, v_sign, u, v):
    """Point with axis a at s*H and the other two axes at their given values."""
    c = [0.0, 0.0, 0.0]
    c[a] = s * H
    c[u] = u_sign * (H - B)
    c[v] = v_sign * (H - B)
    return tuple(c)


def face_quad(a, s, u, v, us, vs):
    return [P(a, s, us, vs, u, v), P(a, s, us, -vs, u, v),
            P(a, s, -us, -vs, u, v), P(a, s, -us, vs, u, v)]


def edge_quad(a, u, v, us, vs):
    """Chamfer strip running along axis a, on the edge shared by axes u and v."""
    pts = []
    for t in (1, -1):
        c1 = [0.0, 0.0, 0.0]
        c1[a] = t * H
        c1[u] = us * H
        c1[v] = vs * (H - B)
        c2 = [0.0, 0.0, 0.0]
        c2[a] = t * H
        c2[u] = us * (H - B)
        c2[v] = vs * H
        pts.append(tuple(c1))
        pts.append(tuple(c2))
    return pts


def corner_tri(u, v, w, us, vs, ws):
    a = [0.0, 0.0, 0.0]
    a[0] = us * H
    a[1] = vs * (H - B)
    a[2] = ws * (H - B)
    b = [0.0, 0.0, 0.0]
    b[0] = us * (H - B)
    b[1] = vs * H
    b[2] = ws * (H - B)
    c = [0.0, 0.0, 0.0]
    c[0] = us * (H - B)
    c[1] = vs * (H - B)
    c[2] = ws * H
    return [tuple(a), tuple(b), tuple(c)]


def normal_of(pts):
    ax, ay, az = pts[0]
    bx, by, bz = pts[1]
    cx, cy, cz = pts[2]
    ux, uy, uz = bx - ax, by - ay, bz - az
    vx, vy, vz = cx - ax, cy - ay, cz - az
    nx = uy * vz - uz * vy
    ny = uz * vx - ux * vz
    nz = ux * vy - uy * vx
    ln = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return nx / ln, ny / ln, nz / ln


def ordered(pts, normal):
    """Sort the polygon vertices CCW around its normal, then fix winding."""
    nx, ny, nz = normal
    # basis
    ref = (1.0, 0.0, 0.0) if abs(nx) < 0.9 else (0.0, 1.0, 0.0)
    ux = ref[1] * nz - ref[2] * ny
    uy = ref[2] * nx - ref[0] * nz
    uz = ref[0] * ny - ref[1] * nx
    ln = math.sqrt(ux * ux + uy * uy + uz * uz) or 1.0
    ux, uy, uz = ux / ln, uy / ln, uz / ln
    vx = ny * uz - nz * uy
    vy = nz * ux - nx * uz
    vz = nx * uy - ny * ux
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    cz = sum(p[2] for p in pts) / len(pts)
    keyed = []
    for p in pts:
        dx, dy, dz = p[0] - cx, p[1] - cy, p[2] - cz
        keyed.append((math.atan2(dx * vx + dy * vy + dz * vz,
                                 dx * ux + dy * uy + dz * uz), p))
    keyed.sort(key=lambda t: t[0])
    out = [p for _, p in keyed]
    n2 = normal_of(out)
    if n2[0] * nx + n2[1] * ny + n2[2] * nz < 0:
        out.reverse()
    return out


def build():
    faces = []
    # six flats
    pairs = {0: (1, 2), 1: (0, 2), 2: (0, 1)}
    for a in (0, 1, 2):
        u, v = pairs[a]
        for s in (1, -1):
            for us in (1, -1):
                for vs in (1, -1):
                    faces.append(face_quad(a, s, u, v, us, vs))
    # twelve chamfer strips
    for a in (0, 1, 2):
        u, v = pairs[a]
        for us in (1, -1):
            for vs in (1, -1):
                faces.append(edge_quad(a, u, v, us, vs))
    # eight corners
    for us in (1, -1):
        for vs in (1, -1):
            for ws in (1, -1):
                faces.append(corner_tri(0, 1, 2, us, vs, ws))

    verts, norms, tris = [], [], []
    for f in faces:
        n = normal_of(f)
        f = ordered(f, n)
        idx = []
        for p in f:
            verts.append(p)
            norms.append(n)
            idx.append(len(verts))
        for i in range(1, len(idx) - 1):
            tris.append((idx[0], idx[i], idx[i + 1]))
    return verts, norms, tris


def write(path):
    verts, norms, tris = build()
    lines = ["# chamfered cube 100cm, chamfer %.2fcm" % B]
    for v in verts:
        lines.append("v %.4f %.4f %.4f" % v)
    for n in norms:
        lines.append("vn %.4f %.4f %.4f" % n)
    for i, j, k in tris:
        lines.append("f %d//%d %d//%d %d//%d" % (i, i, j, j, k, k))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(path, len(verts), "verts", len(tris), "tris")


if __name__ == "__main__":
    write(r"E:\魔法图书馆\Content\Meshes\SM_BevelCube.obj")
