# -*- coding: utf-8 -*-
"""Minimal MCP (Streamable HTTP) client for Unreal Editor's built-in MCP server.

Usage:
    python client.py init
    python client.py tools
    python client.py call <tool_name> '<json args>'
    python client.py meta <meta_tool> '<json args>'
"""
import json
import sys
import urllib.request
import urllib.error

URL = "http://127.0.0.1:8000/mcp"
PROTOCOL = "2025-06-18"


class MCP(object):
    def __init__(self, url=URL):
        self.url = url
        self.session = None
        self._id = 0

    def _post(self, payload):
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self.url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json, text/event-stream")
        if self.session:
            req.add_header("Mcp-Session-Id", self.session)
        try:
            with urllib.request.urlopen(req, timeout=300) as r:
                sid = r.headers.get("Mcp-Session-Id")
                if sid:
                    self.session = sid
                ctype = r.headers.get("Content-Type", "")
                body = r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            raise RuntimeError("HTTP %s: %s" % (e.code, e.read().decode("utf-8", "replace")))
        return ctype, body

    @staticmethod
    def _parse(ctype, body):
        if not body.strip():
            return None
        if "text/event-stream" in ctype:
            events = []
            for line in body.splitlines():
                line = line.strip()
                if line.startswith("data:"):
                    try:
                        events.append(json.loads(line[5:].strip()))
                    except ValueError:
                        pass
            return events[-1] if events else None
        return json.loads(body)

    def request(self, method, params=None, notify=False):
        msg = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            msg["params"] = params
        if not notify:
            self._id += 1
            msg["id"] = self._id
        ctype, body = self._post(msg)
        if notify:
            return None
        resp = self._parse(ctype, body)
        if resp and "error" in resp:
            raise RuntimeError(json.dumps(resp["error"], ensure_ascii=False))
        return resp.get("result") if resp else None

    def connect(self):
        res = self.request("initialize", {
            "protocolVersion": PROTOCOL,
            "capabilities": {},
            "clientInfo": {"name": "dsh-agent", "version": "1.0"},
        })
        self.request("notifications/initialized", None, notify=True)
        return res

    def tools(self):
        return self.request("tools/list", {})

    def call(self, name, args):
        return self.request("tools/call", {"name": name, "arguments": args})


def _text(result):
    """Flatten MCP tool result content into text."""
    if not isinstance(result, dict):
        return result
    items = result.get("content") or []
    out = []
    for it in items:
        if it.get("type") == "text":
            out.append(it.get("text", ""))
        else:
            out.append(json.dumps(it, ensure_ascii=False))
    if result.get("structuredContent") is not None:
        out.append(json.dumps(result["structuredContent"], ensure_ascii=False))
    return "\n".join(out)


def _argv_to_args(tokens):
    """Accept a JSON blob, an @file, or key=value pairs (values parsed as JSON if possible)."""
    if not tokens:
        return {}
    raw = " ".join(tokens).strip()
    if raw.startswith("@"):
        with open(raw[1:], "r", encoding="utf-8") as f:
            return json.load(f)
    if raw.startswith("{"):
        return json.loads(raw)
    out = {}
    for tok in tokens:
        if "=" not in tok:
            continue
        k, v = tok.split("=", 1)
        try:
            out[k] = json.loads(v)
        except ValueError:
            out[k] = v
    return out


def main(argv):
    m = MCP()
    m.connect()
    cmd = argv[1] if len(argv) > 1 else "init"

    if cmd == "init":
        tl = m.tools()
        print(json.dumps(tl, ensure_ascii=False, indent=2)[:4000])
    elif cmd == "tools":
        print(json.dumps(m.tools(), ensure_ascii=False, indent=2))
    elif cmd == "call":
        print(_text(m.call(argv[2], _argv_to_args(argv[3:]))))
    elif cmd == "meta":
        print(json.dumps(m.call(argv[2], _argv_to_args(argv[3:])), ensure_ascii=False, indent=2))
    elif cmd == "names":
        res = m.call("describe_toolset", {"toolset_name": argv[2]})
        raw = (res.get("content") or [{}])[0].get("text", "")
        data = json.loads(raw)
        for t in data.get("tools", []):
            short = " ".join((t.get("description") or "").split())[:110]
            print("%-52s %s" % (t["name"], short))
    elif cmd == "shot":
        import base64
        import os
        out = argv[2]
        args = _argv_to_args(argv[3:])
        res = m.call("call_tool", {"toolset_name": "EditorToolset.EditorAppToolset",
                                   "tool_name": "CaptureViewport", "arguments": args})
        raw = (res.get("content") or [{}])[0].get("text", "")
        data = json.loads(raw)
        img = data["image"]["data"]
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "wb") as f:
            f.write(base64.b64decode(img))
        meta = {k: v for k, v in data.items() if k != "image"}
        print("saved", out)
        print(json.dumps(meta, ensure_ascii=False)[:1200])
    elif cmd == "tool":
        # tool <toolset>.<tool> key=value...
        full = argv[2]
        toolset, _, tool = full.rpartition(".")
        res = m.call("call_tool", {"toolset_name": toolset, "tool_name": tool,
                                   "arguments": _argv_to_args(argv[3:])})
        print(_text(res))
    else:
        raise SystemExit("unknown command: " + cmd)


if __name__ == "__main__":
    main(sys.argv)
