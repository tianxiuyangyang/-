import bpy, math, os
from mathutils import Vector

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

def mat(name, color, metallic=0.0, rough=0.7):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (*color, 1.0)
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = rough
    return m

def box(name, loc, size, material, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o = bpy.context.object
    o.name = name
    o.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(material)
    if bevel:
        b = o.modifiers.new('Cloth edge softness', 'BEVEL')
        b.width, b.segments = bevel, 2
    return o

def uv_sphere(name, loc, scale, material):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, location=loc)
    o = bpy.context.object
    o.name = name
    o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(material)
    return o

def cylinder(name, a, b, radius, material, vertices=20):
    start, end = Vector(a), Vector(b)
    delta = end - start
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=delta.length, location=(start + end) * 0.5)
    o = bpy.context.object
    o.name = name
    o.rotation_euler = delta.to_track_quat('Z', 'Y').to_euler()
    o.data.materials.append(material)
    return o

def cone(name, loc, r1, r2, depth, material, vertices=32):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=r1, radius2=r2, depth=depth, location=loc)
    o = bpy.context.object
    o.name = name
    o.data.materials.append(material)
    b = o.modifiers.new('Soft sewn edges', 'BEVEL')
    b.width, b.segments = 0.025, 2
    return o

raincoat = mat('Faded yellow raincoat', (1.0, 0.62, 0.075), 0.02, 0.58)
raincoat_light = mat('Raincoat edge highlights', (1.0, 0.82, 0.20), 0.02, 0.52)
seam = mat('Raincoat seams', (0.16, 0.095, 0.025), 0.02, 0.72)
hood_dark = mat('Deep hood interior', (0.045, 0.032, 0.018), 0.0, 0.9)
skin = mat('Shadowed skin', (0.16, 0.105, 0.065), 0.0, 0.88)
boot = mat('Scuffed rubber boots', (0.045, 0.038, 0.030), 0.05, 0.72)
sole = mat('Boot sole', (0.012, 0.014, 0.013), 0.0, 0.92)

for coat in (raincoat, raincoat_light):
    shader = coat.node_tree.nodes.get('Principled BSDF')
    if shader and 'Emission Color' in shader.inputs:
        shader.inputs['Emission Color'].default_value = (0.10, 0.055, 0.008, 1.0)
        shader.inputs['Emission Strength'].default_value = 0.18

# A compact, hooded raincoat child, roughly 1.3 Blender units tall.
cone('Raincoat body', (0, 0, 0.72), 0.46, 0.27, 0.92, raincoat)
cone('Raincoat hem', (0, 0, 0.28), 0.53, 0.46, 0.12, raincoat_light)
box('Front zipper flap', (0, -0.285, 0.74), (0.055, 0.035, 0.76), seam, 0.018)
box('Waist seam', (0, -0.29, 0.54), (0.72, 0.035, 0.035), seam, 0.012)

# Hood, hidden face, and a small triangular hood peak.
uv_sphere('Shadowed face', (0, -0.005, 1.30), (0.25, 0.22, 0.29), skin)
cone('Hood crown', (0, 0, 1.38), 0.40, 0.23, 0.43, raincoat)
torus = None
bpy.ops.mesh.primitive_torus_add(major_radius=0.31, minor_radius=0.055, major_segments=32, minor_segments=10, location=(0, -0.015, 1.22))
hood_ring = bpy.context.object
hood_ring.name = 'Hood brim'
hood_ring.data.materials.append(raincoat_light)
cone('Hood peak', (0, 0.18, 1.52), 0.20, 0.035, 0.36, raincoat, vertices=4)
box('Hood inner shadow', (0, -0.235, 1.27), (0.38, 0.035, 0.25), hood_dark, 0.04)

# Sleeves hang slightly forward; hands remain visible beneath the cuffs.
cylinder('Left sleeve', (-0.29, -0.02, 1.05), (-0.54, -0.12, 0.62), 0.115, raincoat, 18)
cylinder('Right sleeve', (0.29, -0.02, 1.05), (0.54, -0.12, 0.62), 0.115, raincoat, 18)
uv_sphere('Left hand', (-0.55, -0.13, 0.56), (0.095, 0.09, 0.11), skin)
uv_sphere('Right hand', (0.55, -0.13, 0.56), (0.095, 0.09, 0.11), skin)
box('Left cuff', (-0.47, -0.10, 0.70), (0.17, 0.16, 0.12), raincoat_light, 0.035)
box('Right cuff', (0.47, -0.10, 0.70), (0.17, 0.16, 0.12), raincoat_light, 0.035)

# Short legs and heavy boots give the silhouette enough weight on the table.
cylinder('Left trouser', (-0.16, 0, 0.27), (-0.18, -0.015, 0.03), 0.12, hood_dark, 16)
cylinder('Right trouser', (0.16, 0, 0.27), (0.18, -0.015, 0.03), 0.12, hood_dark, 16)
box('Left boot', (-0.18, -0.105, -0.03), (0.25, 0.42, 0.20), boot, 0.055)
box('Right boot', (0.18, -0.105, -0.03), (0.25, 0.42, 0.20), boot, 0.055)
box('Left boot sole', (-0.18, -0.12, -0.145), (0.29, 0.44, 0.055), sole, 0.018)
box('Right boot sole', (0.18, -0.12, -0.145), (0.29, 0.44, 0.055), sole, 0.018)

# Slightly irregular stitching marks on the coat hem.
for x in (-0.31, -0.16, 0.0, 0.16, 0.31):
    box('Hem stitch', (x, -0.285, 0.28), (0.035, 0.025, 0.065), seam, 0.008)

project_dir = os.path.dirname(os.path.abspath(__file__))
out_path = os.path.join(project_dir, 'character_model.glb')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(project_dir, 'character_model.blend'))
bpy.ops.export_scene.gltf(filepath=out_path, export_format='GLB', export_materials='EXPORT', export_apply=True, export_cameras=False, export_lights=False)
print('Exported', out_path)
