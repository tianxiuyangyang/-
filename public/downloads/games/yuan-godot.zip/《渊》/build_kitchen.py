import bpy, math, os

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

def mat(name, color, metallic=0.0, rough=0.7):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (*color, 1)
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = rough
    return m

def box(name, loc, size, material, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o = bpy.context.object
    o.name = name
    o.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(material)
    if bevel:
        b = o.modifiers.new('Rounded edges', 'BEVEL')
        b.width, b.segments = bevel, 2
    return o

def cylinder(name, loc, radius, depth, material, rotation=(0, 0, 0), vertices=24):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rotation)
    o = bpy.context.object
    o.name = name
    o.data.materials.append(material)
    return o

def torus(name, loc, major, minor, material, rotation=(0, 0, 0)):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, major_segments=32, minor_segments=10, location=loc, rotation=rotation)
    o = bpy.context.object
    o.name = name
    o.data.materials.append(material)
    return o

steel = mat('Brushed stainless steel', (0.25, 0.30, 0.30), 0.82, 0.27)
dark_steel = mat('Aged steel', (0.08, 0.12, 0.12), 0.72, 0.42)
green = mat('Deep galley green', (0.035, 0.10, 0.08), 0.08, 0.5)
green_dark = mat('Green shadow', (0.015, 0.035, 0.03), 0.05, 0.68)
wood = mat('Oiled dark wood', (0.22, 0.10, 0.05), 0.0, 0.64)
wood_worn = mat('Worn wood edge', (0.40, 0.19, 0.08), 0.0, 0.72)
tile = mat('Aged cream tile', (0.40, 0.38, 0.29), 0.0, 0.78)
glass = mat('Smoky blue glass', (0.03, 0.12, 0.15), 0.2, 0.18)
brass = mat('Tarnished brass', (0.45, 0.23, 0.06), 0.7, 0.35)
black = mat('Black rubber', (0.006, 0.008, 0.007), 0.0, 0.86)
ceramic = mat('Chipped ceramic', (0.52, 0.48, 0.36), 0.0, 0.7)
red = mat('Warning red', (0.35, 0.025, 0.012), 0.1, 0.45)

# Open-front steel hull.
box('Floor', (0, -0.12, 0), (12, 0.24, 14), green_dark, 0.08)
box('Back bulkhead', (0, 3.9, -6.8), (12, 7.8, 0.34), green_dark, 0.08)
box('Left bulkhead', (-6, 3.9, 0), (0.34, 7.8, 14), green_dark, 0.08)
box('Right bulkhead', (6, 3.9, 0), (0.34, 7.8, 14), green_dark, 0.08)
box('Ceiling', (0, 7.8, 0), (12, 0.30, 14), green_dark, 0.05)
for x in (-5.55, -3.7, -1.85, 0, 1.85, 3.7, 5.55):
    box('Hull rib', (x, 3.9, -6.56), (0.18, 7.25, 0.18), dark_steel, 0.04)
    box('Ceiling rib', (x, 7.58, 0), (0.16, 0.26, 13.3), dark_steel, 0.03)
for z in (-5.4, -2.7, 0, 2.7, 5.4):
    box('Side frame L', (-5.76, 3.9, z), (0.22, 7.2, 0.18), dark_steel, 0.04)
    box('Side frame R', (5.76, 3.9, z), (0.22, 7.2, 0.18), dark_steel, 0.04)

# Rear tiled work line.
for row in range(4):
    for col in range(10):
        x = -5.0 + col * 1.1 + (0.55 if row % 2 else 0)
        box('Backsplash tile', (x, 2.25 + row * 0.68, -6.56), (1.02, 0.58, 0.07), tile, 0.025)
for i, x in enumerate((-4.85, -3.25, -1.65, 0, 1.65, 3.25, 4.85)):
    box('Base cabinet', (x, 1.0, -5.45), (1.48, 1.95, 1.52), green, 0.06)
    box('Inset door', (x, 1.0, -4.61), (0.96, 1.27, 0.025), wood, 0.02)
    cylinder('Door pull', (x, 1.0, -4.54), 0.035, 0.48, brass, rotation=(math.pi / 2, 0, 0), vertices=16)
box('Rear worktop', (0, 2.06, -5.45), (11.2, 0.24, 1.78), steel, 0.06)
box('Worktop lip', (0, 2.15, -4.58), (11.2, 0.20, 0.12), dark_steel, 0.025)
for x in (-4.75, -3.15, 3.15, 4.75):
    box('Upper cabinet', (x, 5.25, -5.72), (1.42, 1.52, 1.25), wood, 0.05)
    box('Upper door', (x, 5.25, -5.04), (1.16, 1.22, 0.05), wood_worn, 0.035)
    cylinder('Upper handle', (x, 5.25, -5.0), 0.026, 0.34, brass, rotation=(math.pi / 2, 0, 0), vertices=12)
box('Shelf top', (0, 5.85, -5.68), (4.8, 0.14, 1.2), wood_worn, 0.035)
box('Shelf lower', (0, 4.42, -5.68), (4.8, 0.14, 1.2), wood_worn, 0.035)
for x in (-2.25, 2.25):
    box('Shelf divider', (x, 5.12, -5.68), (0.12, 1.36, 1.18), wood_worn, 0.025)

# Sink with brass gooseneck.
box('Sink basin', (-3.15, 2.20, -5.42), (2.1, 0.18, 1.12), dark_steel, 0.10)
box('Sink inner', (-3.15, 2.32, -5.43), (1.72, 0.08, 0.76), black, 0.08)
cylinder('Faucet stem', (-3.15, 3.18, -5.98), 0.08, 1.20, brass, vertices=20)
torus('Faucet arch', (-3.15, 3.78, -5.66), 0.37, 0.065, brass, rotation=(math.pi / 2, 0, 0))
cylinder('Faucet nozzle', (-3.15, 3.50, -5.31), 0.09, 0.34, brass, rotation=(math.pi / 2, 0, 0), vertices=20)

# Range and oven.
box('Range body', (1.15, 1.05, -5.42), (3, 1.95, 1.55), dark_steel, 0.06)
box('Oven glass', (1.15, 1.1, -4.60), (2.35, 1.2, 0.06), glass, 0.035)
box('Oven frame', (1.15, 1.1, -4.57), (2.48, 1.34, 0.06), steel, 0.035)
for x in (0.25, 1.15, 2.05):
    cylinder('Stove knob', (x, 2.25, -5.58), 0.10, 0.07, brass, rotation=(math.pi / 2, 0, 0), vertices=24)
for x in (0.45, 1.85):
    for z in (-5.90, -4.95):
        torus('Burner ring', (x, 2.35, z), 0.34, 0.055, black)
box('Extractor hood', (1.15, 5.0, -5.48), (4, 0.68, 1.55), steel, 0.08)
box('Hood underside', (1.15, 4.62, -5.48), (3.4, 0.10, 1.12), dark_steel, 0.04)
for x in (0.15, 1.15, 2.15):
    box('Hood filter', (x, 4.56, -5.48), (0.65, 0.025, 0.74), black, 0.02)
cylinder('Hood exhaust pipe', (1.15, 6.2, -5.48), 0.42, 2.2, dark_steel, vertices=32)

# Island with chopping board and knife rack.
box('Island body', (0, 1.05, -1.0), (4.4, 1.85, 1.55), wood, 0.08)
box('Island top', (0, 2.08, -1.0), (4.75, 0.22, 1.82), steel, 0.06)
for x in (-1.45, 0, 1.45):
    box('Island panel', (x, 1.05, -0.20), (1.15, 1.45, 0.06), wood_worn, 0.025)
box('Chopping board', (-1.05, 2.24, -1.02), (1.4, 0.10, 0.88), wood_worn, 0.05)
box('Knife rack', (1.15, 2.40, -1.02), (1.35, 0.12, 0.16), dark_steel, 0.03)
for x in (0.75, 1.15, 1.55):
    box('Knife', (x, 2.62, -1.02), (0.05, 0.62, 0.18), steel, 0.015)

# Hanging rail and pans.
cylinder('Hanging rail', (0, 6.62, -1.15), 0.08, 5.0, brass, rotation=(0, math.pi / 2, 0), vertices=20)
for x in (-1.8, -0.6, 0.6, 1.8):
    cylinder('Rack chain', (x, 7.1, -1.15), 0.025, 0.95, dark_steel, vertices=12)
    torus('Hanging pan', (x, 6.45, -1.15), 0.34 if x != 0 else 0.43, 0.06, steel, rotation=(math.pi / 2, 0, 0))
    cylinder('Pan handle', (x + 0.42, 6.48, -1.15), 0.06, 0.72, dark_steel, rotation=(0, math.pi / 2, 0), vertices=16)

# Pots, plates, pantry tins.
cylinder('Stock pot', (3.95, 2.43, -5.43), 0.45, 0.30, steel, vertices=32)
torus('Pot rim', (3.95, 2.60, -5.43), 0.43, 0.045, dark_steel)
cylinder('Pot lid knob', (3.95, 2.82, -5.43), 0.10, 0.12, brass, vertices=20)
for i, x in enumerate((-4.45, -3.95, -3.45)):
    cylinder('Stacked plate', (x, 2.40 + i * 0.05, -5.38), 0.34, 0.06, ceramic, vertices=32)
for i, x in enumerate((3.3, 3.8, 4.3)):
    box('Pantry tin', (x, 3.0, -5.50), (0.35, 0.70 + 0.12 * (i % 2), 0.35), red if i == 1 else brass, 0.035)

# Blue porthole and exposed ceiling conduit.
cylinder('Porthole frame', (4.65, 4.55, -6.42), 0.82, 0.18, brass, rotation=(math.pi / 2, 0, 0), vertices=48)
cylinder('Porthole glass', (4.65, 4.55, -6.54), 0.66, 0.04, glass, rotation=(math.pi / 2, 0, 0), vertices=48)
for a in (0, math.pi / 2, math.pi, math.pi * 1.5):
    cylinder('Porthole bolt', (4.65 + math.cos(a) * 0.74, 4.55 + math.sin(a) * 0.74, -6.57), 0.045, 0.05, brass, rotation=(math.pi / 2, 0, 0), vertices=12)
cylinder('Ceiling conduit', (-4.2, 7.18, -2.0), 0.11, 8.0, dark_steel, rotation=(0, math.pi / 2, 0), vertices=20)
box('Warning plate', (-5.72, 4.8, -3.8), (0.04, 0.95, 1.4), red, 0.02)

# Engineering details that make the galley read as used, watertight ship space.
grate = mat('Wet steel grate', (0.12, 0.16, 0.16), 0.78, 0.34)
wet = mat('Dark wet floor', (0.018, 0.032, 0.032), 0.25, 0.20)
for z in (-5.0, -3.8, -2.6, -1.4, -0.2, 1.0, 2.2, 3.4, 4.6):
    box('Floor anti-slip rail', (0.0, 0.035, z), (10.2, 0.045, 0.065), grate, 0.015)
for x in (-4.8, -2.4, 0.0, 2.4, 4.8):
    box('Floor cross rail', (x, 0.04, -0.2), (0.065, 0.05, 9.6), grate, 0.015)
for x, z, sx, sz in ((-4.2, 3.6, 1.4, 0.7), (2.6, 2.8, 1.8, 0.55), (-1.8, -4.0, 1.0, 0.45)):
    box('Oil damp floor mark', (x, 0.022, z), (sx, 0.014, sz), wet, 0.12)
cylinder('Floor drain', (-3.9, 0.06, -2.8), 0.34, 0.06, dark_steel, rotation=(math.pi / 2, 0, 0), vertices=32)
torus('Drain rim', (-3.9, 0.095, -2.8), 0.27, 0.035, brass, rotation=(math.pi / 2, 0, 0))

for x in (-5.25, -3.45, -1.65, 0.15, 1.95, 3.75, 5.25):
    for y in (1.15, 6.65):
        cylinder('Bulkhead rivet', (x, y, -6.36), 0.055, 0.06, brass, vertices=16)
for x in (-5.75, 5.75):
    for z in (-5.0, -2.5, 0.0, 2.5, 5.0):
        for y in (1.2, 6.5):
            cylinder('Side rivet', (x, y, z), 0.05, 0.06, brass, rotation=(0, math.pi / 2, 0), vertices=16)

for x in (-4.85, -3.25, -1.65, 0.0, 1.65, 3.25, 4.85):
    for y in (0.45, 1.65):
        cylinder('Cabinet hinge', (x - 0.53, y, -4.58), 0.055, 0.11, dark_steel, rotation=(math.pi / 2, 0, 0), vertices=16)

# Steam valve and pipe couplers above the work line.
cylinder('Steam pipe', (-4.5, 6.75, -5.9), 0.13, 4.2, dark_steel, rotation=(0, math.pi / 2, 0), vertices=20)
for x in (-3.1, -1.7, -0.3):
    torus('Pipe coupler', (x, 6.75, -5.9), 0.16, 0.035, brass, rotation=(0, math.pi / 2, 0))
cylinder('Valve stem', (-1.0, 6.75, -5.9), 0.06, 0.65, brass, rotation=(0, math.pi / 2, 0), vertices=16)
torus('Valve wheel', (-1.0, 7.10, -5.9), 0.28, 0.045, brass, rotation=(0, math.pi / 2, 0))

project_dir = os.path.dirname(os.path.abspath(__file__))
out_path = os.path.join(project_dir, 'kitchen_model.glb')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(project_dir, 'kitchen_model.blend'))
bpy.ops.export_scene.gltf(filepath=out_path, export_format='GLB', export_materials='EXPORT', export_apply=True, export_cameras=False, export_lights=False)
print('Exported', out_path)
