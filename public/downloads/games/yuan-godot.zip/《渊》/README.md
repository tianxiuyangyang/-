# 《渊》·船舱厨房第一关

这是《渊》的第一关原型：暴风雨中的船舱厨房。场景由 Blender 制作，包含不锈钢炉台、烤箱、水槽、瓷砖后挡板、橱柜、中岛、吊锅、舷窗和外露船肋。穿黄色雨衣的孩子被困在中岛上，Godot 负责冷海光、暖色实用灯、雾效、角色控制、调查交互和谜题状态。

用 Godot 4.7 打开 `project.godot`，按 **F6** 或 **F5** 运行。使用 **WASD** 或方向键移动，**Space** 或 **Enter** 跳跃（空中再按一次可二段跳到桌面），按住鼠标右键或中键拖动环视，滚轮缩放。靠近物件后按 **E** 调查，按 **R** 重置本关，按 **Esc** 退出。

第一关的闭环是：

1. 调查中岛上的航海日志。
2. 查看后舱停摆的厨房钟，确认时间 **04:27**。
3. 在冷藏柜密码盘输入 `0427`。
4. 取出出现的黄铜钥匙，打开船尾舱门。

`kitchen.gd` 负责组装场景和推进谜题状态；`scripts/interactable.gd` 提供可高亮交互物；`scripts/puzzle_hud.gd` 提供目标、线索、密码输入和提示界面；`scripts/feedback_fx.gd` 提供无外部素材依赖的声音、闪光和脉冲反馈。后续关卡可以复用这些脚本，只替换道具、线索和状态回调。

本关的三个调查道具由 Godot 运行时程序化组装：航海日志包含皮革封面、书脊、压边、书签、搭扣和纸面字迹；厨房钟包含金属底座、黄铜表圈、玻璃、12 个刻度、04:27 指针、中心轴帽和固定螺钉；船尾舱门包含甲板开口、金属门框、橡胶密封圈、铰链、把手、八枚黄铜螺栓和舱内海光。舱门打开时，门板围绕后缘铰链向上抬起约 108 度，铰链动作持续 1.45 秒，舱内冷光延迟后渐亮；按 `R` 会同时复位门板和灯光。

`scripts/hatch_animation.gd` 是可复用的舱门动画控制器，支持 `play_open_animation()`、`reset_hatch()` 和开启动作信号。后续可以将它配置到任何带 `Node3D` 铰链和 `Light3D` 的门、柜门或机关上。

The player uses the web-sourced KayKit Adventurers hooded character, scaled to 0.30 so its height is about 0.68 m in the galley. The model includes a rig and authored Idle, Running, and Jump animations. It is released under CC0; the original license is kept at `assets/kaykit/LICENSE.txt`.

Source: [KayKit Adventurers Character Pack](https://github.com/KayKit-Game-Assets/KayKit-Character-Pack-Adventures-1.0) by Kay Lousberg.

`build_kitchen.py` can rebuild `kitchen_model.glb` with Blender 5.1 if you need to change the modeling pass.
