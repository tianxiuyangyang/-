@echo off
setlocal

set "PROJECT_DIR=%~dp0"
set "GODOT_EXE=E:\Godot_v4.7.2-stable_win64.exe\Godot_v4.7.2-stable_win64.exe"

if not exist "%GODOT_EXE%" (
    echo Godot 4.7.2 was not found:
    echo %GODOT_EXE%
    echo Please check the Godot installation path.
    pause
    exit /b 1
)

cd /d "%PROJECT_DIR%"

if not exist "project.godot" (
    echo project.godot was not found next to this batch file.
    pause
    exit /b 1
)

"%GODOT_EXE%" --path .
if errorlevel 1 (
    echo Godot exited with an error.
    pause
)
exit /b 0
