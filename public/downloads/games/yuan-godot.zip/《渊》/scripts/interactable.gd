extends Area3D
class_name Interactable

## A small, reusable interaction target for investigative scenes.
##
## Add a CollisionShape3D below this Area3D and connect `interacted` from the
## scene controller. The controller can use `interaction_id` to route the
## interaction without needing to know anything about the visual children.

signal interacted(actor: Node)
signal highlighted_changed(is_highlighted: bool)

@export var prompt_text: String = "调查"
@export var interaction_id: StringName = &""
@export var enabled: bool = true
@export var highlight_enabled: bool = true
@export var highlight_color: Color = Color(0.26, 0.86, 1.0, 1.0)
@export_range(0.0, 1.0, 0.01) var highlight_alpha: float = 0.24
@export_range(0.0, 8.0, 0.05) var highlight_energy: float = 1.6

var _highlighted := false
var _original_overlays: Dictionary = {}
var _highlight_material: StandardMaterial3D


func _ready() -> void:
	# Area3D is intentionally passive. A scene controller may use a ray query,
	# body overlap, or an interaction manager to decide which target is active.
	monitoring = true


func get_prompt() -> String:
	if not enabled:
		return ""
	return prompt_text.strip_edges()


func interact(actor: Node) -> bool:
	if not enabled:
		return false
	interacted.emit(actor)
	return true


func set_enabled(value: bool) -> void:
	enabled = value
	if not enabled:
		highlight_clear()


func set_highlighted(value: bool) -> void:
	if _highlighted == value:
		return
	_highlighted = value
	if _highlighted and enabled and highlight_enabled:
		_apply_highlight()
	else:
		_clear_highlight()
	highlighted_changed.emit(_highlighted)


func is_highlighted() -> bool:
	return _highlighted


func highlight() -> void:
	set_highlighted(true)


func highlight_clear() -> void:
	set_highlighted(false)


func _apply_highlight() -> void:
	if _highlight_material == null:
		_highlight_material = StandardMaterial3D.new()
		_highlight_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_highlight_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_highlight_material.albedo_color = Color(highlight_color.r, highlight_color.g, highlight_color.b, highlight_alpha)
		_highlight_material.emission_enabled = true
		_highlight_material.emission = highlight_color
		_highlight_material.emission_energy_multiplier = highlight_energy

	for node in find_children("*", "GeometryInstance3D", true, false):
		var geometry := node as GeometryInstance3D
		if geometry == null:
			continue
		if not _original_overlays.has(geometry):
			_original_overlays[geometry] = geometry.material_overlay
		geometry.material_overlay = _highlight_material


func _clear_highlight() -> void:
	for geometry in _original_overlays:
		if is_instance_valid(geometry):
			geometry.material_overlay = _original_overlays[geometry]
	_original_overlays.clear()
