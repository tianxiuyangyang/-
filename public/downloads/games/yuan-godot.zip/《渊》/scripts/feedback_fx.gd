class_name FeedbackFX
extends CanvasLayer

## Lightweight, asset-free presentation feedback for investigation gameplay.
## Add an instance to a scene and call success(), failure(), or inspect().

const CARD_WIDTH := 420.0
const CARD_HEIGHT := 92.0
const CARD_TOP := 42.0
const TOAST_HOLD := 2.8

var _root: Control
var _flash: ColorRect
var _card: PanelContainer
var _badge_dot: ColorRect
var _badge: Label
var _title: Label
var _detail: Label
var _pulse: PulseCanvas
var _audio_player: AudioStreamPlayer
var _generator: AudioStreamGenerator
var _card_tween: Tween
var _flash_tween: Tween
var _last_event := ""


class PulseCanvas extends Control:
	var _rings: Array[Dictionary] = []

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func pulse(color: Color, strength := 1.0) -> void:
		_rings.append({"age": 0.0, "color": color, "strength": strength})
		if _rings.size() > 4:
			_rings.pop_front()
		queue_redraw()

	func _process(delta: float) -> void:
		for index in range(_rings.size() - 1, -1, -1):
			var ring := _rings[index]
			ring["age"] = float(ring["age"]) + delta
			_rings[index] = ring
			if float(ring["age"]) > 0.72:
				_rings.remove_at(index)
		queue_redraw()

	func _draw() -> void:
		var center := size * 0.5
		for ring in _rings:
			var age := float(ring["age"])
			var progress: float = clampf(age / 0.72, 0.0, 1.0)
			var radius: float = lerpf(18.0, 132.0, ease(progress, 0.72))
			var color: Color = ring["color"]
			color.a = (1.0 - progress) * 0.34 * float(ring["strength"])
			draw_arc(center, radius, 0.0, TAU, 64, color, 2.0, true)
			var inner := color
			inner.a *= 0.42
			draw_arc(center, radius * 0.62, 0.0, TAU, 48, inner, 1.0, true)


func _ready() -> void:
	layer = 60
	_build_ui()
	_build_audio()


func _build_ui() -> void:
	_root = Control.new()
	_root.name = "FeedbackOverlay"
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	_flash = ColorRect.new()
	_flash.name = "EventFlash"
	_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_flash.color = Color(0.0, 0.0, 0.0, 0.0)
	_root.add_child(_flash)

	_pulse = PulseCanvas.new()
	_pulse.name = "CenterPulse"
	_pulse.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(_pulse)

	_card = PanelContainer.new()
	_card.name = "EventCard"
	_card.anchor_left = 0.5
	_card.anchor_right = 0.5
	_card.anchor_top = 0.0
	_card.anchor_bottom = 0.0
	_card.offset_left = -CARD_WIDTH * 0.5
	_card.offset_right = CARD_WIDTH * 0.5
	_card.offset_top = CARD_TOP
	_card.offset_bottom = CARD_TOP + CARD_HEIGHT
	_card.pivot_offset = Vector2(CARD_WIDTH * 0.5, CARD_HEIGHT * 0.5)
	_card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_card.modulate.a = 0.0
	_card.scale = Vector2(0.96, 0.96)
	_root.add_child(_card)

	var panel_margin := MarginContainer.new()
	panel_margin.add_theme_constant_override("margin_left", 18)
	panel_margin.add_theme_constant_override("margin_right", 18)
	panel_margin.add_theme_constant_override("margin_top", 13)
	panel_margin.add_theme_constant_override("margin_bottom", 12)
	_card.add_child(panel_margin)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 3)
	panel_margin.add_child(column)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	column.add_child(header)

	_badge_dot = ColorRect.new()
	_badge_dot.custom_minimum_size = Vector2(7, 7)
	_badge_dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_badge_dot.color = Color("#74d1c0")
	header.add_child(_badge_dot)

	_badge = Label.new()
	_badge.text = "SIGNAL"
	_badge.add_theme_font_size_override("font_size", 11)
	_badge.add_theme_color_override("font_color", Color("#74d1c0"))
	_badge.add_theme_constant_override("outline_size", 3)
	_badge.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.35))
	header.add_child(_badge)

	_title = Label.new()
	_title.text = "Interaction registered"
	_title.add_theme_font_size_override("font_size", 18)
	_title.add_theme_color_override("font_color", Color("#ecf4f0"))
	_title.add_theme_constant_override("outline_size", 4)
	_title.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.45))
	column.add_child(_title)

	_detail = Label.new()
	_detail.text = ""
	_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_detail.add_theme_font_size_override("font_size", 13)
	_detail.add_theme_color_override("font_color", Color("#a9bcb8"))
	_detail.add_theme_constant_override("outline_size", 3)
	_detail.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.35))
	column.add_child(_detail)

	_set_card_style(Color("#74d1c0"))


func _build_audio() -> void:
	_generator = AudioStreamGenerator.new()
	_generator.mix_rate = 44100.0
	_generator.buffer_length = 0.45
	_audio_player = AudioStreamPlayer.new()
	_audio_player.name = "FeedbackTone"
	_audio_player.stream = _generator
	_audio_player.volume_db = -10.0
	_audio_player.bus = &"Master"
	add_child(_audio_player)


func success(message: String = "Clue confirmed", detail: String = "") -> void:
	_show_event("CONFIRMED", message, detail, Color("#75d6a6"), [523.25, 659.25, 783.99], 0.075, 1.0)


func failure(message: String = "That does not fit", detail: String = "") -> void:
	_show_event("REJECTED", message, detail, Color("#e58e82"), [196.0, 146.83], 0.095, 0.82)


func inspect(message: String = "Something catches your eye", detail: String = "") -> void:
	_show_event("OBSERVATION", message, detail, Color("#7ec5d5"), [659.25, 783.99], 0.065, 0.68)


func hint(message: String = "A detail may be worth revisiting", detail: String = "") -> void:
	_show_event("INTUITION", message, detail, Color("#d7b978"), [440.0, 554.37], 0.09, 0.58)


func clear() -> void:
	if is_instance_valid(_card_tween):
		_card_tween.kill()
	if _card:
		_card.modulate.a = 0.0
	_last_event = ""


func _show_event(kind: String, message: String, detail: String, color: Color, notes: Array, note_duration: float, strength: float) -> void:
	if not is_inside_tree():
		return
	_last_event = kind
	_badge.text = kind
	_badge.add_theme_color_override("font_color", color)
	_badge_dot.color = color
	_title.text = message
	_detail.text = detail
	_detail.visible = not detail.is_empty()
	_set_card_style(color)
	_pulse.pulse(color, strength)
	_play_pattern(notes, note_duration, strength * 0.75)
	_flash_event(color, strength)
	_animate_card()


func _set_card_style(accent: Color) -> void:
	if not _card:
		return
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#101a1e")
	style.bg_color.a = 0.94
	style.border_color = Color(accent, 0.42)
	style.set_border_width_all(1)
	style.set_corner_radius_all(9)
	style.shadow_color = Color(0, 0, 0, 0.42)
	style.shadow_size = 14
	style.shadow_offset = Vector2(0, 5)
	_card.add_theme_stylebox_override("panel", style)


func _animate_card() -> void:
	if is_instance_valid(_card_tween):
		_card_tween.kill()
	_card.modulate.a = 0.0
	_card.scale = Vector2(0.96, 0.96)
	_card_tween = create_tween()
	_card_tween.set_parallel(true)
	_card_tween.tween_property(_card, "modulate:a", 1.0, 0.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_card_tween.tween_property(_card, "scale", Vector2.ONE, 0.24).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_card_tween.set_parallel(false)
	_card_tween.tween_interval(TOAST_HOLD)
	_card_tween.tween_property(_card, "modulate:a", 0.0, 0.34).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)


func _flash_event(color: Color, strength: float) -> void:
	if is_instance_valid(_flash_tween):
		_flash_tween.kill()
	var flash := color
	flash.a = 0.07 * strength
	_flash.color = flash
	_flash_tween = create_tween()
	_flash_tween.tween_property(_flash, "color:a", 0.0, 0.42).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func _play_pattern(notes: Array, note_duration: float, volume: float) -> void:
	if not _audio_player or not _generator:
		return
	if not _audio_player.playing:
		_audio_player.play()
	var playback := _audio_player.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback == null:
		return
	var gap := 0.012
	for frequency_variant in notes:
		var frequency := float(frequency_variant)
		_push_tone(playback, frequency, note_duration, volume)
		_push_silence(playback, gap)


func _push_tone(playback: AudioStreamGeneratorPlayback, frequency: float, duration: float, volume: float) -> void:
	var frames := maxi(1, int(_generator.mix_rate * duration))
	for frame in range(frames):
		var phase := float(frame) / _generator.mix_rate
		var envelope := minf(1.0, float(frame) / (_generator.mix_rate * 0.008))
		envelope *= minf(1.0, float(frames - frame) / (_generator.mix_rate * 0.02))
		var sample := sin(TAU * frequency * phase) * volume * envelope
		playback.push_frame(Vector2(sample, sample))


func _push_silence(playback: AudioStreamGeneratorPlayback, duration: float) -> void:
	var frames := maxi(1, int(_generator.mix_rate * duration))
	for _frame in range(frames):
		playback.push_frame(Vector2.ZERO)
