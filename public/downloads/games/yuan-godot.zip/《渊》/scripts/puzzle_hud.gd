extends CanvasLayer
class_name PuzzleHUD

## Runtime HUD for a contained investigation or puzzle sequence.
##
## The scene controller can either instantiate this class and call `setup`, or
## use `PuzzleHUD.create(root)`. All controls are created here so a level does
## not need a separate UI scene just to expose the interaction contract.

var _ui_root: Control
var _objective_label: Label
var _prompt_panel: PanelContainer
var _prompt_label: Label
var _clue_panel: PanelContainer
var _clue_list: VBoxContainer
var _toast_panel: PanelContainer
var _toast_label: Label
var _complete_label: Label
var _code_panel: PanelContainer
var _code_title: Label
var _code_input: LineEdit
var _code_feedback: Label
var _code_callback: Callable
var _clues: Array[Dictionary] = []
var _toast_serial := 0
var _built := false


static func create(root: Node) -> PuzzleHUD:
	var hud := PuzzleHUD.new()
	if root != null:
		root.add_child(hud)
	hud.setup(root)
	return hud


func _ready() -> void:
	_build_ui()


func setup(root: Node = null) -> PuzzleHUD:
	# Allow setup to be called before the HUD is parented, which is convenient
	# when a scene controller owns all of its runtime helpers.
	if root != null and not is_inside_tree() and get_parent() == null:
		root.add_child(self)
	_build_ui()
	return self


func set_objective(text: String) -> void:
	_build_ui()
	_objective_label.text = text.strip_edges()


func show_prompt(text: String) -> void:
	_build_ui()
	_prompt_label.text = text.strip_edges()
	_prompt_panel.visible = not _prompt_label.text.is_empty()


func hide_prompt() -> void:
	_build_ui()
	_prompt_panel.visible = false


func add_clue(title: String, text: String) -> void:
	_build_ui()
	_clues.append({"title": title.strip_edges(), "text": text.strip_edges()})
	_render_clues()
	_clue_panel.visible = true


func clear_clues() -> void:
	_build_ui()
	_clues.clear()
	_render_clues()
	_clue_panel.visible = false


func open_code_input(title: String, callback: Callable) -> void:
	_build_ui()
	_code_title.text = title.strip_edges()
	_code_feedback.text = ""
	_code_feedback.visible = false
	_code_input.text = ""
	_code_callback = callback
	_code_panel.visible = true
	_code_input.grab_focus()


func close_code_input() -> void:
	_build_ui()
	_code_panel.visible = false
	_code_callback = Callable()


func is_code_input_open() -> bool:
	_build_ui()
	return _code_panel.visible


func show_message(text: String, color: Color = Color(0.86, 0.94, 0.96, 1.0)) -> void:
	_build_ui()
	_toast_serial += 1
	var serial := _toast_serial
	_toast_label.text = text.strip_edges()
	_toast_label.add_theme_color_override("font_color", color)
	_toast_panel.visible = not _toast_label.text.is_empty()
	if get_tree() != null:
		get_tree().create_timer(3.2).timeout.connect(func() -> void:
			if serial == _toast_serial and is_instance_valid(_toast_panel):
				_toast_panel.visible = false
		)


func show_complete() -> void:
	_build_ui()
	_objective_label.text = "目标完成"
	_complete_label.visible = true
	hide_prompt()
	show_message("谜题已解开", Color(0.48, 0.96, 0.78, 1.0))


func set_code_feedback(text: String, color: Color = Color(1.0, 0.55, 0.42, 1.0)) -> void:
	_build_ui()
	_code_feedback.text = text
	_code_feedback.add_theme_color_override("font_color", color)
	_code_feedback.visible = not text.is_empty()


func _submit_code(value: String) -> void:
	var code := value.strip_edges()
	if code.is_empty():
		set_code_feedback("请输入密码")
		return
	if _code_callback.is_valid():
		_code_callback.call(code)


func _build_ui() -> void:
	if _built:
		return
	_built = true
	layer = 20

	_ui_root = Control.new()
	_ui_root.name = "PuzzleHUDRoot"
	_ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_ui_root)

	_build_objective()
	_build_prompt()
	_build_clues()
	_build_toast()
	_build_code_input()


func _build_objective() -> void:
	var panel := PanelContainer.new()
	panel.name = "ObjectivePanel"
	panel.position = Vector2(24.0, 24.0)
	panel.custom_minimum_size = Vector2(330.0, 82.0)
	panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.07, 0.085, 0.92), Color(0.30, 0.72, 0.78, 0.55), 7))
	_ui_root.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 5)
	panel.add_child(box)
	var heading := Label.new()
	heading.text = "当前目标"
	heading.add_theme_color_override("font_color", Color(0.42, 0.83, 0.86, 1.0))
	heading.add_theme_font_size_override("font_size", 12)
	box.add_child(heading)
	_objective_label = Label.new()
	_objective_label.text = "调查船舱"
	_objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_objective_label.add_theme_color_override("font_color", Color(0.91, 0.96, 0.96, 1.0))
	_objective_label.add_theme_font_size_override("font_size", 17)
	box.add_child(_objective_label)
	_complete_label = Label.new()
	_complete_label.text = "已完成"
	_complete_label.add_theme_color_override("font_color", Color(0.48, 0.96, 0.78, 1.0))
	_complete_label.visible = false
	box.add_child(_complete_label)


func _build_prompt() -> void:
	_prompt_panel = PanelContainer.new()
	_prompt_panel.name = "InteractionPrompt"
	_prompt_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_prompt_panel.position = Vector2(-235.0, -78.0)
	_prompt_panel.size = Vector2(470.0, 48.0)
	_prompt_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.015, 0.028, 0.035, 0.94), Color(0.56, 0.80, 0.82, 0.72), 6))
	_prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui_root.add_child(_prompt_panel)
	_prompt_label = Label.new()
	_prompt_label.text = ""
	_prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_prompt_label.add_theme_color_override("font_color", Color(0.93, 0.97, 0.97, 1.0))
	_prompt_label.add_theme_font_size_override("font_size", 15)
	_prompt_panel.add_child(_prompt_label)
	_prompt_panel.visible = false


func _build_clues() -> void:
	_clue_panel = PanelContainer.new()
	_clue_panel.name = "CluePanel"
	_clue_panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_clue_panel.position = Vector2(-348.0, 24.0)
	_clue_panel.size = Vector2(324.0, 220.0)
	_clue_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.07, 0.085, 0.92), Color(0.30, 0.72, 0.78, 0.55), 7))
	_clue_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui_root.add_child(_clue_panel)
	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 8)
	_clue_panel.add_child(outer)
	var heading := Label.new()
	heading.text = "线索记录"
	heading.add_theme_color_override("font_color", Color(0.42, 0.83, 0.86, 1.0))
	heading.add_theme_font_size_override("font_size", 12)
	outer.add_child(heading)
	_clue_list = VBoxContainer.new()
	_clue_list.add_theme_constant_override("separation", 6)
	_clue_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(_clue_list)
	_clue_panel.visible = false


func _build_toast() -> void:
	_toast_panel = PanelContainer.new()
	_toast_panel.name = "MessageToast"
	_toast_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_toast_panel.position = Vector2(-240.0, 118.0)
	_toast_panel.size = Vector2(480.0, 42.0)
	_toast_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.015, 0.028, 0.035, 0.96), Color(0.56, 0.80, 0.82, 0.65), 6))
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui_root.add_child(_toast_panel)
	_toast_label = Label.new()
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_toast_label.add_theme_font_size_override("font_size", 14)
	_toast_panel.add_child(_toast_label)
	_toast_panel.visible = false


func _build_code_input() -> void:
	_code_panel = PanelContainer.new()
	_code_panel.name = "CodeInputPanel"
	_code_panel.set_anchors_preset(Control.PRESET_CENTER)
	_code_panel.position = Vector2(-205.0, -122.0)
	_code_panel.size = Vector2(410.0, 244.0)
	_code_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.05, 0.06, 0.98), Color(0.46, 0.84, 0.86, 0.85), 8))
	_code_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_ui_root.add_child(_code_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	_code_panel.add_child(box)
	_code_title = Label.new()
	_code_title.text = "输入密码"
	_code_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_code_title.add_theme_color_override("font_color", Color(0.91, 0.96, 0.96, 1.0))
	_code_title.add_theme_font_size_override("font_size", 19)
	box.add_child(_code_title)
	_code_input = LineEdit.new()
	_code_input.placeholder_text = "密码"
	_code_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	_code_input.add_theme_font_size_override("font_size", 18)
	_code_input.text_submitted.connect(_on_code_submitted)
	box.add_child(_code_input)
	_code_feedback = Label.new()
	_code_feedback.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_code_feedback.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_code_feedback.visible = false
	box.add_child(_code_feedback)
	var buttons := HBoxContainer.new()
	buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("separation", 10)
	box.add_child(buttons)
	var submit := Button.new()
	submit.text = "确认"
	submit.custom_minimum_size = Vector2(112.0, 36.0)
	submit.pressed.connect(_on_code_submitted.bind(""))
	buttons.add_child(submit)
	var cancel := Button.new()
	cancel.text = "取消"
	cancel.custom_minimum_size = Vector2(112.0, 36.0)
	cancel.pressed.connect(close_code_input)
	buttons.add_child(cancel)
	_code_panel.visible = false


func _on_code_submitted(value: String) -> void:
	if value.is_empty():
		_submit_code(_code_input.text)
	else:
		_submit_code(value)


func _render_clues() -> void:
	for child in _clue_list.get_children():
		child.queue_free()
	for clue in _clues:
		var title := Label.new()
		title.text = str(clue.get("title", "线索"))
		title.add_theme_color_override("font_color", Color(0.88, 0.95, 0.95, 1.0))
		title.add_theme_font_size_override("font_size", 14)
		_clue_list.add_child(title)
		var body := Label.new()
		body.text = str(clue.get("text", ""))
		body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		body.add_theme_color_override("font_color", Color(0.65, 0.78, 0.80, 1.0))
		body.add_theme_font_size_override("font_size", 12)
		_clue_list.add_child(body)


func _panel_style(background: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = border
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	style.corner_radius_top_left = radius
	style.corner_radius_top_right = radius
	style.corner_radius_bottom_right = radius
	style.corner_radius_bottom_left = radius
	style.content_margin_left = 16.0
	style.content_margin_top = 12.0
	style.content_margin_right = 16.0
	style.content_margin_bottom = 12.0
	return style
