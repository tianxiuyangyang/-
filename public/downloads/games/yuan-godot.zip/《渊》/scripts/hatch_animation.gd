extends Node
class_name HatchAnimation

## Reusable opening animation for a hinged hatch or door.
##
## The helper can be configured from the inspector with `hinge_path` and
## `light_paths`, or wired at runtime with `configure()`. It keeps the closed
## transform and light levels so `reset_hatch()` can restore the puzzle state.

signal opening_started
signal opening_completed
signal opening_failed(reason: String)

@export var hinge_path: NodePath = NodePath("")
@export var light_paths: Array[NodePath] = []
@export var open_rotation_degrees: Vector3 = Vector3(0.0, 72.0, 0.0)
@export_range(0.1, 10.0, 0.05) var open_duration: float = 1.2
@export_range(0.0, 5.0, 0.05) var light_delay: float = 0.12
@export_range(0.1, 10.0, 0.05) var light_fade_duration: float = 1.0
@export_range(0.0, 100.0, 0.1) var default_light_energy: float = 3.5
@export var auto_bind_on_ready: bool = true

var hinge: Node3D
var lights: Array[Light3D] = []

var _closed_rotation := Vector3.ZERO
var _closed_light_energy: Array[float] = []
var _target_light_energy: Array[float] = []
var _door_tween: Tween
var _light_tween: Tween
var _door_finished := false
var _lights_finished := false
var _is_opening := false
var _is_open := false


func _ready() -> void:
	if auto_bind_on_ready:
		call_deferred("_bind_exported_nodes")


func _bind_exported_nodes() -> void:
	if not hinge_path.is_empty():
		var hinge_node := get_node_or_null(hinge_path)
		if hinge_node is Node3D:
			set_hinge(hinge_node as Node3D)
	for path in light_paths:
		var light_node := get_node_or_null(path)
		if light_node is Light3D:
			_register_light(light_node as Light3D)


## Configure the helper from code. `target_lights` accepts OmniLight3D,
## SpotLight3D, DirectionalLight3D, or any other Light3D subclass.
func configure(hatch_hinge: Node3D, target_lights: Array = []) -> void:
	set_hinge(hatch_hinge)
	set_lights(target_lights)


func set_hinge(hatch_hinge: Node3D) -> void:
	if hatch_hinge == null or not is_instance_valid(hatch_hinge):
		hinge = null
		return
	hinge = hatch_hinge
	_closed_rotation = hinge.rotation
	_is_open = false


func set_lights(target_lights: Array) -> void:
	lights.clear()
	_closed_light_energy.clear()
	_target_light_energy.clear()
	for candidate in target_lights:
		var light := candidate as Light3D
		if light == null:
			continue
		_register_light(light)


func _register_light(light: Light3D) -> void:
	if light == null or not is_instance_valid(light) or lights.has(light):
		return
	lights.append(light)
	var current_energy := maxf(light.light_energy, 0.0)
	_closed_light_energy.append(current_energy)
	_target_light_energy.append(default_light_energy if current_energy <= 0.01 else current_energy)


## Start the opening sequence. The `opening_completed` signal fires only after
## the hinge and all registered lights finish their tweens.
func play_open_animation() -> void:
	if _is_opening or _is_open:
		return
	if hinge == null or not is_instance_valid(hinge):
		opening_failed.emit("A valid Node3D hinge is required.")
		return

	_stop_tweens()
	_is_opening = true
	_door_finished = false
	_lights_finished = lights.is_empty()
	opening_started.emit()

	for light in lights:
		if is_instance_valid(light):
			light.light_energy = 0.0

	var target_rotation := _closed_rotation + Vector3(
		deg_to_rad(open_rotation_degrees.x),
		deg_to_rad(open_rotation_degrees.y),
		deg_to_rad(open_rotation_degrees.z)
	)
	_door_tween = create_tween()
	_door_tween.tween_property(hinge, "rotation", target_rotation, open_duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_door_tween.tween_callback(_mark_door_finished)

	if not _lights_finished:
		_light_tween = create_tween()
		if light_delay > 0.0:
			_light_tween.tween_interval(light_delay)
		var first_light := true
		for index in range(lights.size()):
			var light := lights[index]
			if not is_instance_valid(light):
				continue
			var light_tweener
			if first_light:
				light_tweener = _light_tween.tween_property(light, "light_energy", _target_light_energy[index], light_fade_duration)
				first_light = false
			else:
				light_tweener = _light_tween.parallel().tween_property(light, "light_energy", _target_light_energy[index], light_fade_duration)
			light_tweener.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		_light_tween.tween_callback(_mark_lights_finished)
	else:
		_finish_if_ready()


## Short alias for callers that prefer a verb-style API.
func open() -> void:
	play_open_animation()


func reset_hatch() -> void:
	_stop_tweens()
	_is_opening = false
	_is_open = false
	_door_finished = false
	_lights_finished = false
	if hinge != null and is_instance_valid(hinge):
		hinge.rotation = _closed_rotation
	for index in range(lights.size()):
		if is_instance_valid(lights[index]) and index < _closed_light_energy.size():
			lights[index].light_energy = _closed_light_energy[index]


func is_open() -> bool:
	return _is_open


func is_opening() -> bool:
	return _is_opening


func _mark_door_finished() -> void:
	_door_finished = true
	_finish_if_ready()


func _mark_lights_finished() -> void:
	_lights_finished = true
	_finish_if_ready()


func _finish_if_ready() -> void:
	if not _is_opening or not _door_finished or not _lights_finished:
		return
	_is_opening = false
	_is_open = true
	opening_completed.emit()


func _stop_tweens() -> void:
	if _door_tween != null:
		_door_tween.kill()
	if _light_tween != null:
		_light_tween.kill()
