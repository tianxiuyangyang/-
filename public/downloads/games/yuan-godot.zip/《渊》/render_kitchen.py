import bpy, math, os
from mathutils import Vector

exec(compile(open('build_kitchen.py', 'r', encoding='utf-8').read(), 'build_kitchen.py', 'exec'))

def aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()

world = bpy.context.scene.world
world.use_nodes = True
world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.004, 0.009, 0.012, 1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.18

bpy.ops.object.camera_add(location=(3.6, 4.1, 10.8))
camera = bpy.context.object
camera.data.lens = 30
aim(camera, (0.0, 3.05, -4.25))
bpy.context.scene.camera = camera

def area(name, loc, energy, color, size, target):
    bpy.ops.object.light_add(type='AREA', location=loc)
    light = bpy.context.object
    light.name = name
    light.data.energy = energy
    light.data.color = color
    light.data.shape = 'DISK'
    light.data.size = size
    aim(light, target)

area('Hood warmth', (1.15, 4.3, -4.4), 650, (1.0, 0.42, 0.15), 3.0, (1.0, 1.0, -4.8))
area('Island warmth', (-0.2, 4.8, -0.8), 420, (1.0, 0.55, 0.22), 2.4, (0.0, 0.8, -1.0))
area('Porthole blue', (4.5, 4.5, -4.7), 800, (0.18, 0.55, 0.82), 2.0, (0.0, 3.0, -3.5))
area('Ceiling fill', (0, 7.3, 1.0), 500, (0.45, 0.62, 0.66), 5.0, (0, 0, -3))

scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'
scene.render.resolution_x = 1024
scene.render.resolution_y = 576
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kitchen_preview.png')
scene.render.film_transparent = False
scene.view_settings.look = 'AgX - Medium High Contrast'
bpy.ops.render.render(write_still=True)
print('Rendered kitchen_preview.png')
