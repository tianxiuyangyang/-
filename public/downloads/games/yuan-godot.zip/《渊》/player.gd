extends CharacterBody3D

const MOVE_SPEED := 2.8
const ACCELERATION := 12.0
## Each jump rises about 1.10 m. Two timed jumps reach the galley table top.
const JUMP_VELOCITY := 5.2
const GRAVITY := 12.0
const MAX_JUMPS := 2

var visual: Node3D
var animation_player: AnimationPlayer
var facing := Vector3.FORWARD
var current_animation := ""
var jumps_remaining := MAX_JUMPS
var jump_was_down := false

func _ready() -> void:
	# Keep the body grounded on the thin island top without pulling the small
	# character into the table at edges.
	motion_mode = CharacterBody3D.MOTION_MODE_GROUNDED
	up_direction = Vector3.UP
	floor_snap_length = 0.04
	floor_max_angle = deg_to_rad(50.0)
	floor_stop_on_slope = true
	safe_margin = 0.012
	max_slides = 8
	_load_visual()

func _load_visual() -> void:
	visual = preload("res://assets/kaykit/YellowRogue.tscn").instantiate()
	visual.name = "YellowRaincoatVisual"
	visual.scale = Vector3.ONE * 0.30
	visual.position.y = 0.0
	add_child(visual)
	animation_player = visual.get_node_or_null("AnimationPlayer") as AnimationPlayer
	if animation_player:
		animation_player.animation_finished.connect(_on_animation_finished)
		_play_animation("Idle")

func _play_animation(animation_name: String) -> void:
	if not animation_player or not animation_player.has_animation(animation_name):
		return
	if current_animation == animation_name and animation_player.is_playing():
		return
	current_animation = animation_name
	animation_player.play(animation_name)

func _on_animation_finished(animation_name: StringName) -> void:
	if animation_name == &"Jump_Land":
		current_animation = ""

func _physics_process(delta: float) -> void:
	var was_on_floor := is_on_floor()
	if was_on_floor:
		jumps_remaining = MAX_JUMPS
	var jump_down := Input.is_physical_key_pressed(KEY_SPACE) or Input.is_physical_key_pressed(KEY_ENTER)
	var jump_pressed := jump_down and not jump_was_down
	jump_was_down = jump_down
	var input_vector := _read_move_input()
	var direction := Vector3(input_vector.x, 0.0, input_vector.y)
	if direction.length_squared() > 0.01:
		direction = direction.normalized()
		facing = direction
		# KayKit's character faces its local +Z axis.
		rotation.y = lerp_angle(rotation.y, atan2(direction.x, direction.z), delta * 10.0)
		velocity.x = move_toward(velocity.x, direction.x * MOVE_SPEED, ACCELERATION * delta)
		velocity.z = move_toward(velocity.z, direction.z * MOVE_SPEED, ACCELERATION * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, ACCELERATION * delta)
		velocity.z = move_toward(velocity.z, 0.0, ACCELERATION * delta)

	if not was_on_floor:
		velocity.y -= GRAVITY * delta
	if jump_pressed and jumps_remaining > 0:
		velocity.y = JUMP_VELOCITY
		jumps_remaining -= 1
		_play_animation("Jump_Start")
	move_and_slide()

	var on_floor_now := is_on_floor()
	if not on_floor_now:
		if velocity.y <= 0.0:
			_play_animation("Jump_Full_Short")
	elif not was_on_floor:
		_play_animation("Jump_Land")
	else:
		var horizontal_speed := Vector2(velocity.x, velocity.z).length()
		_play_animation("Running_A" if horizontal_speed > 0.15 else "Idle")

func _read_move_input() -> Vector2:
	var x := 0.0
	var y := 0.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		x -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		x += 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		y -= 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		y += 1.0
	return Vector2(x, y).normalized()
