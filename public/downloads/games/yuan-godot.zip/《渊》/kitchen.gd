extends Node3D

var kitchen_model: Node3D
var flicker_lights: Array[OmniLight3D] = []
var flicker_base: Array[float] = []
var elapsed := 0.0
var camera: Camera3D
var orbit_target := Vector3(0.0, 3.05, -4.25)
var orbit_yaw := 0.235
var orbit_pitch := 0.068
var orbit_distance := 8.5
var orbit_dragging := false
const CAMERA_MOUSE_SENSITIVITY := 0.0045
var player: CharacterBody3D
var hud: PuzzleHUD
var feedback: FeedbackFX
var interactables: Array[Interactable] = []
var current_target: Interactable
var log_item: Interactable
var clock_item: Interactable
var locker_item: Interactable
var key_item: Interactable
var hatch_item: Interactable
var key_visual: Node3D
var hatch_visual: Node3D
var hatch_pivot: Node3D
var hatch_light: OmniLight3D
var hatch_animation: HatchAnimation
var locker_visual: Node3D
var log_found := false
var clock_found := false
var locker_unlocked := false
var key_collected := false
var puzzle_complete := false

func _ready() -> void:
	_build_world()
	_load_blender_model()
	_build_lights()
	_build_collision()
	_spawn_player()
	_build_camera()
	_build_puzzle_props()
	_build_game_ui()

func _load_blender_model() -> void:
	var document := GLTFDocument.new()
	var state := GLTFState.new()
	var error := document.append_from_file("res://kitchen_model.glb", state)
	if error != OK:
		push_error("Unable to load kitchen_model.glb: %s" % error)
		return
	kitchen_model = document.generate_scene(state)
	kitchen_model.name = "BlenderGalleyModel"
	kitchen_model.rotation_degrees.x = 90.0
	add_child(kitchen_model)


func _build_game_ui() -> void:
	hud = PuzzleHUD.create(self)
	hud.set_objective("调查船舱，寻找离开的方法")
	hud.show_message("WASD 移动 · Space 二段跳 · 按住右键拖动视角", Color(0.66, 0.84, 0.86, 1.0))
	feedback = FeedbackFX.new()
	add_child(feedback)

	var controls_layer := CanvasLayer.new()
	controls_layer.layer = 18
	add_child(controls_layer)
	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-8.0, -14.0)
	crosshair.size = Vector2(16.0, 28.0)
	crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	crosshair.add_theme_font_size_override("font_size", 20)
	crosshair.add_theme_color_override("font_color", Color(0.74, 0.9, 0.89, 0.72))
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	controls_layer.add_child(crosshair)


func _build_puzzle_props() -> void:
	log_item = _create_interactable("ShipLog", "调查航海日志", &"log", Vector3(-1.05, 2.25, -1.25), _build_log_visual())
	clock_item = _create_interactable("GalleyClock", "查看停摆的厨房钟", &"clock", Vector3(-3.15, 2.37, -5.03), _build_clock_visual())
	locker_item = _create_interactable("ColdLocker", "检查冷藏柜密码盘", &"locker", Vector3(3.65, 2.74, -5.02), _build_locker_visual())
	key_item = _create_interactable("BrassKey", "拿起黄铜钥匙", &"key", Vector3(3.65, 3.31, -5.02), _build_key_visual())
	hatch_item = _create_interactable("EscapeHatch", "检查船尾舱门", &"hatch", Vector3(0.0, 0.12, 5.65), _build_hatch_visual())
	key_item.set_enabled(false)
	key_visual = key_item.get_node_or_null("PropVisual")
	if key_visual:
		key_visual.visible = false
	locker_visual = locker_item.get_node_or_null("PropVisual")
	hatch_visual = hatch_item.get_node_or_null("PropVisual")
	if hatch_visual:
		hatch_pivot = hatch_visual.get_node_or_null("DoorPivot") as Node3D
		hatch_light = hatch_visual.get_node_or_null("HatchOceanGlow") as OmniLight3D
		if hatch_pivot:
			hatch_animation = HatchAnimation.new()
			hatch_animation.open_rotation_degrees = Vector3(-108.0, 0.0, 0.0)
			hatch_animation.open_duration = 1.45
			hatch_animation.light_delay = 0.18
			hatch_animation.light_fade_duration = 1.10
			hatch_animation.default_light_energy = 3.0
			add_child(hatch_animation)
			hatch_animation.configure(hatch_pivot, [hatch_light] if hatch_light else [])
	for target in [log_item, clock_item, locker_item, key_item, hatch_item]:
		interactables.append(target)
		target.interacted.connect(_on_interactable_used.bind(target))


func _create_interactable(node_name: String, prompt: String, interaction_id: StringName, pos: Vector3, visual: Node3D) -> Interactable:
	var target := Interactable.new()
	target.name = node_name
	target.prompt_text = prompt
	target.interaction_id = interaction_id
	target.position = pos
	var shape_node := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = 1.35
	shape_node.shape = sphere
	target.add_child(shape_node)
	if visual:
		visual.name = "PropVisual"
		target.add_child(visual)
	add_child(target)
	return target


func _build_log_visual() -> Node3D:
	var root := Node3D.new()
	root.rotation_degrees = Vector3(-1.5, 2.5, -2.0)
	var back_cover := MeshInstance3D.new()
	var back_mesh := BoxMesh.new()
	back_mesh.size = Vector3(0.88, 0.055, 0.62)
	back_cover.position.y = 0.025
	back_cover.mesh = back_mesh
	back_cover.material_override = _prop_material(Color("#3d241b"), Color("#9a5f34"), 0.10, 0.38, 0.05)
	root.add_child(back_cover)
	var pages := MeshInstance3D.new()
	var page_mesh := BoxMesh.new()
	page_mesh.size = Vector3(0.75, 0.105, 0.49)
	pages.position = Vector3(0.025, 0.105, 0.0)
	pages.mesh = page_mesh
	pages.material_override = _prop_material(Color("#b9aa84"), Color("#e4d59f"), 0.02, 0.78)
	root.add_child(pages)
	var front_cover := MeshInstance3D.new()
	var front_mesh := BoxMesh.new()
	front_mesh.size = Vector3(0.88, 0.052, 0.62)
	front_cover.position = Vector3(0.0, 0.18, 0.0)
	front_cover.mesh = front_mesh
	front_cover.material_override = _prop_material(Color("#4b2b20"), Color("#a86b3d"), 0.12, 0.36, 0.04)
	root.add_child(front_cover)
	var spine := MeshInstance3D.new()
	var spine_mesh := BoxMesh.new()
	spine_mesh.size = Vector3(0.075, 0.19, 0.64)
	spine.position = Vector3(-0.425, 0.105, 0.0)
	spine.mesh = spine_mesh
	spine.material_override = _prop_material(Color("#2c1814"), Color("#75452c"), 0.08, 0.40, 0.03)
	root.add_child(spine)
	for index in range(4):
		var band := MeshInstance3D.new()
		var band_mesh := BoxMesh.new()
		band_mesh.size = Vector3(0.018, 0.20, 0.66)
		band.position = Vector3(-0.405 + float(index % 2) * 0.015, 0.105, -0.26 + float(index / 2) * 0.52)
		band.mesh = band_mesh
		band.material_override = _prop_material(Color("#70402a"), Color("#bd7b42"), 0.06, 0.42, 0.05)
		root.add_child(band)
	for index in range(5):
		var page_line := MeshInstance3D.new()
		var line_mesh := BoxMesh.new()
		line_mesh.size = Vector3(0.56 - float(index % 2) * 0.12, 0.006, 0.012)
		page_line.position = Vector3(-0.05 + float(index % 2) * 0.03, 0.211, -0.16 + float(index) * 0.07)
		page_line.mesh = line_mesh
		page_line.material_override = _prop_material(Color("#6b6250"), Color("#8d7e60"), 0.0, 0.85)
		root.add_child(page_line)
	var emblem := MeshInstance3D.new()
	var emblem_mesh := TorusMesh.new()
	emblem_mesh.inner_radius = 0.075
	emblem_mesh.outer_radius = 0.10
	emblem_mesh.ring_segments = 20
	emblem_mesh.rings = 6
	emblem.position = Vector3(0.18, 0.212, 0.03)
	emblem.mesh = emblem_mesh
	emblem.material_override = _prop_material(Color("#9b632f"), Color("#e1ad5d"), 0.22, 0.28, 0.55)
	root.add_child(emblem)
	var clasp := MeshInstance3D.new()
	var clasp_mesh := BoxMesh.new()
	clasp_mesh.size = Vector3(0.075, 0.035, 0.15)
	clasp.position = Vector3(0.375, 0.225, 0.0)
	clasp.mesh = clasp_mesh
	clasp.material_override = _prop_material(Color("#a26731"), Color("#f0bd65"), 0.28, 0.24, 0.72)
	root.add_child(clasp)
	var bookmark := MeshInstance3D.new()
	var bookmark_mesh := BoxMesh.new()
	bookmark_mesh.size = Vector3(0.09, 0.012, 0.40)
	bookmark.position = Vector3(0.15, 0.196, 0.10)
	bookmark.mesh = bookmark_mesh
	bookmark.material_override = _prop_material(Color("#8a3430"), Color("#c75246"), 0.08, 0.52, 0.05)
	root.add_child(bookmark)
	return root


func _build_clock_visual() -> Node3D:
	var root := Node3D.new()
	var mounting_plate := MeshInstance3D.new()
	var plate_mesh := CylinderMesh.new()
	plate_mesh.top_radius = 0.39
	plate_mesh.bottom_radius = 0.39
	plate_mesh.height = 0.045
	mounting_plate.position.z = -0.065
	mounting_plate.rotation_degrees.x = 90.0
	mounting_plate.mesh = plate_mesh
	mounting_plate.material_override = _prop_material(Color("#18272b"), Color("#4d8589"), 0.05, 0.42, 0.58)
	root.add_child(mounting_plate)
	var body := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 0.36
	cylinder.bottom_radius = 0.36
	cylinder.height = 0.14
	cylinder.radial_segments = 48
	body.rotation_degrees.x = 90.0
	body.mesh = cylinder
	body.material_override = _prop_material(Color("#2a3a3e"), Color("#7fa9a8"), 0.10, 0.32, 0.78)
	root.add_child(body)
	var rear_ring := MeshInstance3D.new()
	var rear_ring_mesh := TorusMesh.new()
	rear_ring_mesh.inner_radius = 0.325
	rear_ring_mesh.outer_radius = 0.365
	rear_ring_mesh.ring_segments = 48
	rear_ring_mesh.rings = 10
	rear_ring.position.z = -0.08
	rear_ring.rotation_degrees.x = 90.0
	rear_ring.mesh = rear_ring_mesh
	rear_ring.material_override = _prop_material(Color("#0f1b1e"), Color("#34565b"), 0.05, 0.4, 0.85)
	root.add_child(rear_ring)
	var face := MeshInstance3D.new()
	var face_mesh := CylinderMesh.new()
	face_mesh.top_radius = 0.285
	face_mesh.bottom_radius = 0.285
	face_mesh.height = 0.018
	face_mesh.radial_segments = 48
	face.position.z = 0.075
	face.rotation_degrees.x = 90.0
	face.mesh = face_mesh
	face.material_override = _prop_material(Color("#b7bdad"), Color("#d7e1ca"), 0.04, 0.68)
	root.add_child(face)
	for index in range(12):
		var angle := PI * 0.5 - TAU * float(index) / 12.0
		var tick := MeshInstance3D.new()
		var tick_mesh := BoxMesh.new()
		var major := index % 3 == 0
		tick_mesh.size = Vector3(0.024 if major else 0.014, 0.085 if major else 0.050, 0.012)
		tick.position = Vector3(cos(angle) * 0.235, sin(angle) * 0.235, 0.094)
		tick.rotation.z = angle - PI * 0.5
		tick.mesh = tick_mesh
		tick.material_override = _prop_material(Color("#304044"), Color("#6b8583"), 0.0, 0.48, 0.22)
		root.add_child(tick)
	var minute_hand := MeshInstance3D.new()
	var minute_mesh := BoxMesh.new()
	minute_mesh.size = Vector3(0.018, 0.225, 0.012)
	minute_hand.position = Vector3(0.0, 0.0, 0.108)
	minute_hand.rotation.z = deg_to_rad(-162.0)
	minute_hand.mesh = minute_mesh
	minute_hand.material_override = _prop_material(Color("#172528"), Color("#75a6a0"), 0.05, 0.36, 0.36)
	root.add_child(minute_hand)
	var hour_hand := MeshInstance3D.new()
	var hour_mesh := BoxMesh.new()
	hour_mesh.size = Vector3(0.030, 0.16, 0.014)
	hour_hand.position = Vector3(0.0, 0.0, 0.114)
	hour_hand.rotation.z = deg_to_rad(-133.5)
	hour_hand.mesh = hour_mesh
	hour_hand.material_override = _prop_material(Color("#172528"), Color("#75a6a0"), 0.05, 0.36, 0.36)
	root.add_child(hour_hand)
	var hub := MeshInstance3D.new()
	var hub_mesh := CylinderMesh.new()
	hub_mesh.top_radius = 0.035
	hub_mesh.bottom_radius = 0.035
	hub_mesh.height = 0.028
	hub.position.z = 0.125
	hub.rotation_degrees.x = 90.0
	hub.mesh = hub_mesh
	hub.material_override = _prop_material(Color("#b27a3e"), Color("#f1c06e"), 0.25, 0.26, 0.76)
	root.add_child(hub)
	var bezel := MeshInstance3D.new()
	var bezel_mesh := TorusMesh.new()
	bezel_mesh.inner_radius = 0.285
	bezel_mesh.outer_radius = 0.345
	bezel_mesh.ring_segments = 48
	bezel_mesh.rings = 12
	bezel.position.z = 0.115
	bezel.rotation_degrees.x = 90.0
	bezel.mesh = bezel_mesh
	bezel.material_override = _prop_material(Color("#876238"), Color("#e5b768"), 0.16, 0.22, 0.72)
	root.add_child(bezel)
	var glass := MeshInstance3D.new()
	var glass_mesh := CylinderMesh.new()
	glass_mesh.top_radius = 0.292
	glass_mesh.bottom_radius = 0.292
	glass_mesh.height = 0.012
	glass_mesh.radial_segments = 48
	glass.position.z = 0.132
	glass.rotation_degrees.x = 90.0
	glass.mesh = glass_mesh
	var glass_material := StandardMaterial3D.new()
	glass_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass_material.albedo_color = Color(0.52, 0.80, 0.80, 0.16)
	glass_material.metallic = 0.24
	glass_material.roughness = 0.08
	glass_material.emission_enabled = true
	glass_material.emission = Color("#6ba6a4")
	glass_material.emission_energy_multiplier = 0.08
	glass.material_override = glass_material
	root.add_child(glass)
	for index in range(4):
		var screw := MeshInstance3D.new()
		var screw_mesh := CylinderMesh.new()
		screw_mesh.top_radius = 0.022
		screw_mesh.bottom_radius = 0.022
		screw_mesh.height = 0.020
		screw.position = Vector3(cos(float(index) * PI * 0.5 + PI * 0.25) * 0.325, sin(float(index) * PI * 0.5 + PI * 0.25) * 0.325, 0.128)
		screw.rotation_degrees.x = 90.0
		screw.mesh = screw_mesh
		screw.material_override = _prop_material(Color("#b27a3e"), Color("#f1c06e"), 0.16, 0.24, 0.70)
		root.add_child(screw)
	return root


func _build_locker_visual() -> Node3D:
	var root := Node3D.new()
	var body := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(1.08, 1.18, 0.62)
	body.mesh = mesh
	body.material_override = _prop_material(Color("#34444a"), Color("#8db2b1"), 0.08)
	root.add_child(body)
	var dial := MeshInstance3D.new()
	var dial_mesh := CylinderMesh.new()
	dial_mesh.top_radius = 0.18
	dial_mesh.bottom_radius = 0.18
	dial_mesh.height = 0.06
	dial.position = Vector3(0.0, 0.06, -0.34)
	dial.rotation_degrees.x = 90.0
	dial.mesh = dial_mesh
	dial.material_override = _prop_material(Color("#172226"), Color("#8ed8d2"), 0.3)
	root.add_child(dial)
	return root


func _build_key_visual() -> Node3D:
	var root := Node3D.new()
	var shaft := MeshInstance3D.new()
	var shaft_mesh := BoxMesh.new()
	shaft_mesh.size = Vector3(0.48, 0.05, 0.10)
	shaft.position.x = 0.08
	shaft.mesh = shaft_mesh
	shaft.material_override = _prop_material(Color("#bf7c2c"), Color("#ffd36b"), 0.8)
	root.add_child(shaft)
	var ring := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.09
	ring_mesh.outer_radius = 0.14
	ring.position.x = -0.24
	ring.rotation_degrees.x = 90.0
	ring.mesh = ring_mesh
	ring.material_override = _prop_material(Color("#bf7c2c"), Color("#ffd36b"), 0.8)
	root.add_child(ring)
	var tooth := MeshInstance3D.new()
	var tooth_mesh := BoxMesh.new()
	tooth_mesh.size = Vector3(0.11, 0.055, 0.13)
	tooth.position = Vector3(0.29, 0.0, 0.035)
	tooth.mesh = tooth_mesh
	tooth.material_override = shaft.material_override
	root.add_child(tooth)
	return root


func _build_hatch_visual() -> Node3D:
	var root := Node3D.new()
	var opening := MeshInstance3D.new()
	var opening_mesh := CylinderMesh.new()
	opening_mesh.top_radius = 0.79
	opening_mesh.bottom_radius = 0.79
	opening_mesh.height = 0.14
	opening_mesh.radial_segments = 48
	opening.position.y = -0.035
	opening.mesh = opening_mesh
	opening.material_override = _prop_material(Color("#071216"), Color("#1f5661"), 0.28, 0.80)
	root.add_child(opening)
	var rim := MeshInstance3D.new()
	var rim_mesh := TorusMesh.new()
	rim_mesh.inner_radius = 0.76
	rim_mesh.outer_radius = 0.88
	rim_mesh.ring_segments = 48
	rim_mesh.rings = 12
	rim.position.y = 0.02
	rim.mesh = rim_mesh
	rim.material_override = _prop_material(Color("#94602f"), Color("#e7ae58"), 0.32, 0.30, 0.76)
	root.add_child(rim)
	var gasket := MeshInstance3D.new()
	var gasket_mesh := TorusMesh.new()
	gasket_mesh.inner_radius = 0.685
	gasket_mesh.outer_radius = 0.735
	gasket_mesh.ring_segments = 48
	gasket_mesh.rings = 10
	gasket.position.y = 0.055
	gasket.mesh = gasket_mesh
	gasket.material_override = _prop_material(Color("#131b1d"), Color("#253f42"), 0.02, 0.62)
	root.add_child(gasket)
	var pivot := Node3D.new()
	pivot.name = "DoorPivot"
	pivot.position = Vector3(0.0, 0.085, -0.62)
	root.add_child(pivot)
	var hatch := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.745
	mesh.bottom_radius = 0.745
	mesh.height = 0.095
	mesh.radial_segments = 48
	hatch.position.z = 0.62
	hatch.mesh = mesh
	hatch.material_override = _prop_material(Color("#263b3e"), Color("#6fa8a3"), 0.08, 0.42, 0.70)
	pivot.add_child(hatch)
	var inner_panel := MeshInstance3D.new()
	var inner_mesh := CylinderMesh.new()
	inner_mesh.top_radius = 0.57
	inner_mesh.bottom_radius = 0.57
	inner_mesh.height = 0.035
	inner_mesh.radial_segments = 48
	inner_panel.position = Vector3(0.0, 0.055, 0.62)
	inner_panel.mesh = inner_mesh
	inner_panel.material_override = _prop_material(Color("#1c2b2f"), Color("#4c8887"), 0.08, 0.52, 0.36)
	pivot.add_child(inner_panel)
	var door_rim := MeshInstance3D.new()
	var door_rim_mesh := TorusMesh.new()
	door_rim_mesh.inner_radius = 0.60
	door_rim_mesh.outer_radius = 0.70
	door_rim_mesh.ring_segments = 48
	door_rim_mesh.rings = 10
	door_rim.position = Vector3(0.0, 0.082, 0.62)
	door_rim.mesh = door_rim_mesh
	door_rim.material_override = _prop_material(Color("#6d4828"), Color("#d49a4c"), 0.20, 0.34, 0.60)
	pivot.add_child(door_rim)
	var handle := MeshInstance3D.new()
	var handle_mesh := BoxMesh.new()
	handle_mesh.size = Vector3(0.34, 0.065, 0.08)
	handle.position = Vector3(0.0, 0.17, 0.36)
	handle.mesh = handle_mesh
	handle.material_override = _prop_material(Color("#9e6932"), Color("#f0bd67"), 0.32, 0.23, 0.82)
	pivot.add_child(handle)
	for x in [-0.13, 0.13]:
		var support := MeshInstance3D.new()
		var support_mesh := BoxMesh.new()
		support_mesh.size = Vector3(0.045, 0.14, 0.08)
		support.position = Vector3(x, 0.12, 0.36)
		support.mesh = support_mesh
		support.material_override = handle.material_override
		pivot.add_child(support)
	for x in [-0.43, 0.43]:
		var hinge := MeshInstance3D.new()
		var hinge_mesh := CylinderMesh.new()
		hinge_mesh.top_radius = 0.075
		hinge_mesh.bottom_radius = 0.075
		hinge_mesh.height = 0.20
		hinge.position = Vector3(x, 0.095, -0.62)
		hinge.rotation_degrees.z = 90.0
		hinge.mesh = hinge_mesh
		hinge.material_override = _prop_material(Color("#4b3930"), Color("#a77b4a"), 0.08, 0.42, 0.42)
		root.add_child(hinge)
	for index in range(8):
		var angle := TAU * float(index) / 8.0
		var bolt := MeshInstance3D.new()
		var bolt_mesh := CylinderMesh.new()
		bolt_mesh.top_radius = 0.040
		bolt_mesh.bottom_radius = 0.040
		bolt_mesh.height = 0.036
		bolt.position = Vector3(cos(angle) * 0.825, 0.085, sin(angle) * 0.825)
		bolt.rotation_degrees.x = 90.0
		bolt.mesh = bolt_mesh
		bolt.material_override = _prop_material(Color("#bd7b37"), Color("#ffd272"), 0.20, 0.24, 0.78)
		root.add_child(bolt)
	var light := OmniLight3D.new()
	light.name = "HatchOceanGlow"
	light.position = Vector3(0.0, 0.15, 0.0)
	light.light_color = Color("#4eafc0")
	light.light_energy = 0.0
	light.omni_range = 4.0
	light.shadow_enabled = false
	root.add_child(light)
	return root


func _prop_material(base: Color, emission: Color, energy: float, roughness_value: float = 0.48, metallic_value: float = 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = base
	material.roughness = roughness_value
	material.metallic = metallic_value
	if energy > 0.0:
		material.emission_enabled = true
		material.emission = emission
		material.emission_energy_multiplier = energy
	return material

func _process(delta: float) -> void:
	elapsed += delta
	for i in range(flicker_lights.size()):
		var pulse := sin(elapsed * (6.0 + i * 0.8) + i * 1.6) * 0.035
		var dip := -0.18 if fmod(elapsed + i * 1.37, 9.0) < 0.12 else 0.0
		flicker_lights[i].light_energy = flicker_base[i] * (1.0 + pulse + dip)
	if camera:
		if player:
			orbit_target = player.global_position + Vector3(0.0, 0.65, 0.0)
		_update_camera()
	_update_interaction_target()


func _update_interaction_target() -> void:
	if not player or not hud:
		return
	if hud.is_code_input_open():
		if current_target:
			current_target.highlight_clear()
		current_target = null
		hud.hide_prompt()
		return
	var nearest: Interactable
	var nearest_distance := 2.35
	for target in interactables:
		if not is_instance_valid(target) or not target.enabled:
			continue
		var distance := player.global_position.distance_to(target.global_position)
		if distance < nearest_distance:
			nearest = target
			nearest_distance = distance
	if nearest != current_target:
		if current_target:
			current_target.highlight_clear()
		current_target = nearest
		if current_target:
			current_target.highlight()
	if current_target:
		hud.show_prompt("E  ·  " + current_target.get_prompt())
	else:
		hud.hide_prompt()


func _on_interactable_used(_actor: Node, target: Interactable) -> void:
	if puzzle_complete:
		return
	match target.interaction_id:
		&"log":
			if log_found:
				feedback.hint("日志上的字迹仍然清晰", "潮声第三次敲舷时，冷柜只认 04:27。")
				return
			log_found = true
			hud.add_clue("航海日志", "潮声第三次敲舷时，冷柜只认 04:27。")
			hud.set_objective("查看停摆的厨房钟，确认密码线索")
			feedback.inspect("发现一页湿透的航海日志", "最后一行被人用力圈出了一个时间。")
		&"clock":
			if clock_found:
				feedback.hint("指针没有移动", "04:27。和日志上的时间完全一致。")
				return
			clock_found = true
			hud.add_clue("停摆的钟", "指针卡在 04:27，秒针在第三格处断裂。")
			if log_found:
				hud.set_objective("在冷藏柜上输入密码 04:27")
				feedback.success("密码线索完整", "冷藏柜的蓝色指示灯亮了。")
			else:
				hud.set_objective("找到能解释 04:27 的线索")
				feedback.inspect("钟停在 04:27", "这个时间似乎被刻意留下。")
		&"locker":
			if locker_unlocked:
				feedback.hint("冷藏柜已经打开", "里面只剩一把黄铜钥匙。")
				return
			if not log_found or not clock_found:
				hud.set_objective("先调查日志和停摆的钟")
				feedback.failure("密码盘没有反应", "你还缺少确认密码的线索。")
				return
			hud.open_code_input("冷藏柜密码 · 四位数字", _on_code_entered)
			feedback.inspect("密码盘等待输入", "日志和钟的时间都指向同一个答案。")
		&"key":
			if key_collected:
				return
			key_collected = true
			key_item.set_enabled(false)
			if key_visual:
				key_visual.visible = false
			hatch_item.set_enabled(true)
			hud.set_objective("带着黄铜钥匙，打开船尾舱门")
			feedback.success("取得黄铜钥匙", "舱门的锁芯发出了一声回应。")
		&"hatch":
			if not key_collected:
				hud.set_objective("找到能打开舱门的钥匙")
				feedback.failure("舱门锁死了", "锁芯需要一把老式黄铜钥匙。")
				return
			puzzle_complete = true
			hatch_item.set_enabled(false)
			hud.show_complete()
			feedback.success("舱门打开了", "冷风灌进厨房。你终于看见了外面的海。")
			if hatch_animation:
				hatch_animation.play_open_animation()


func _on_code_entered(value: String) -> void:
	if value.strip_edges() == "0427":
		hud.close_code_input()
		locker_unlocked = true
		locker_item.set_enabled(false)
		key_item.set_enabled(true)
		if locker_visual:
			locker_visual.rotation_degrees.y = -12.0
		if key_visual:
			key_visual.visible = true
		hud.set_objective("从冷藏柜里取出黄铜钥匙")
		feedback.success("密码正确", "冷藏柜的门锁松开了。")
	else:
		hud.set_code_feedback("密码不对。再看看日志和钟。")
		feedback.failure("密码错误", "数字没有转动到位。")


func _reset_puzzle() -> void:
	log_found = false
	clock_found = false
	locker_unlocked = false
	key_collected = false
	puzzle_complete = false
	hud.close_code_input()
	hud.clear_clues()
	hud.set_objective("调查船舱，寻找离开的方法")
	key_item.set_enabled(false)
	locker_item.set_enabled(true)
	hatch_item.set_enabled(true)
	if key_visual:
		key_visual.visible = false
	if hatch_animation:
		hatch_animation.reset_hatch()
	feedback.inspect("谜题已重置", "船舱回到了暴风雨来临前的状态。")

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("quit"):
		get_tree().quit()
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_E and not hud.is_code_input_open():
			if current_target:
				current_target.interact(player)
				get_viewport().set_input_as_handled()
				return
		if event.keycode == KEY_R and not hud.is_code_input_open():
			_reset_puzzle()
			get_viewport().set_input_as_handled()
			return
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT or event.button_index == MOUSE_BUTTON_RIGHT or event.button_index == MOUSE_BUTTON_MIDDLE:
			orbit_dragging = event.pressed
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if orbit_dragging else Input.MOUSE_MODE_VISIBLE
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			orbit_distance = clamp(orbit_distance - 0.8, 7.5, 24.0)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			orbit_distance = clamp(orbit_distance + 0.8, 7.5, 24.0)
	if event is InputEventMouseMotion and orbit_dragging:
		orbit_yaw -= event.relative.x * CAMERA_MOUSE_SENSITIVITY
		orbit_pitch = clamp(orbit_pitch + event.relative.y * CAMERA_MOUSE_SENSITIVITY * 0.78, -0.35, 0.62)
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_LEFT:
			orbit_yaw += 0.08
		elif event.keycode == KEY_RIGHT:
			orbit_yaw -= 0.08
		elif event.keycode == KEY_UP:
			orbit_pitch = clamp(orbit_pitch - 0.05, -0.35, 0.62)
		elif event.keycode == KEY_DOWN:
			orbit_pitch = clamp(orbit_pitch + 0.05, -0.35, 0.62)

func _build_world() -> void:
	var world := WorldEnvironment.new()
	world.name = "ColdSaltAir"
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("#03080b")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#263e43")
	env.ambient_light_energy = 0.44
	env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.15
	env.tonemap_white = 1.28
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 0.9
	env.fog_enabled = true
	env.fog_light_color = Color("#537176")
	env.fog_light_energy = 0.26
	env.fog_density = 0.014
	env.fog_height = 1.0
	env.fog_height_density = 0.12
	world.environment = env
	add_child(world)

func _build_lights() -> void:
	var overhead := DirectionalLight3D.new()
	overhead.name = "DeckMoonlight"
	overhead.rotation_degrees = Vector3(-42, 28, 0)
	overhead.light_color = Color("#7b9eaa")
	overhead.light_energy = 0.24
	overhead.shadow_enabled = true
	add_child(overhead)

	_add_warm(Vector3(1.15, 4.35, -4.55), 3.2, 6.2)
	_add_warm(Vector3(-3.3, 3.0, -5.0), 1.0, 4.2)
	_add_warm(Vector3(0.0, 3.2, -1.2), 0.75, 4.5)

	var porthole := OmniLight3D.new()
	porthole.name = "StormBluePorthole"
	porthole.position = Vector3(4.65, 4.55, -5.6)
	porthole.light_color = Color("#3f9bb9")
	porthole.light_energy = 3.0
	porthole.omni_range = 7.5
	porthole.shadow_enabled = true
	add_child(porthole)

	var front_fill := OmniLight3D.new()
	front_fill.name = "LowBlueFill"
	front_fill.position = Vector3(-1.5, 4.8, 6.5)
	front_fill.light_color = Color("#315b68")
	front_fill.light_energy = 0.85
	front_fill.omni_range = 10.0
	add_child(front_fill)

	var hood := SpotLight3D.new()
	hood.name = "HoodPractical"
	hood.position = Vector3(1.15, 4.5, -4.55)
	hood.rotation_degrees = Vector3(-90, 0, 0)
	hood.light_color = Color("#ffc06d")
	hood.light_energy = 3.6
	hood.spot_range = 5.0
	hood.spot_angle = 68.0
	hood.shadow_enabled = true
	add_child(hood)

func _add_warm(pos: Vector3, energy: float, range_value: float) -> void:
	var light := OmniLight3D.new()
	light.position = pos
	light.light_color = Color("#e99a52")
	light.light_energy = energy
	light.omni_range = range_value
	light.shadow_enabled = true
	add_child(light)
	flicker_lights.append(light)
	flicker_base.append(energy)

func _build_camera() -> void:
	camera = Camera3D.new()
	camera.name = "GalleyCinematicCamera"
	camera.fov = 52.0
	camera.near = 0.05
	camera.far = 60.0
	add_child(camera)
	_update_camera()

func _spawn_player() -> void:
	player = preload("res://player.tscn").instantiate()
	player.name = "RaincoatChild"
	# Start on the galley floor beside the island so the double jump can be
	# used to reach the tabletop instead of spawning there directly.
	player.position = Vector3(-4.0, 0.12, -1.0)
	add_child(player)
	var character_fill := OmniLight3D.new()
	character_fill.name = "RaincoatWarmFill"
	character_fill.position = Vector3(0.0, 0.8, -0.35)
	character_fill.light_color = Color("#e6a14a")
	character_fill.light_energy = 0.45
	character_fill.omni_range = 2.4
	character_fill.shadow_enabled = false
	player.add_child(character_fill)
	orbit_target = player.position + Vector3(0.0, 0.65, 0.0)

func _build_collision() -> void:
	# These boxes follow the Blender model's world-space bounds. The GLB has no
	# collision meshes, so explicit boxes keep the walkable surfaces stable.
	_add_collision_box("GalleyFloorCollision", Vector3(0.0, -0.18, 0.0), Vector3(12.0, 0.35, 14.0))
	_add_collision_box("IslandBodyCollision", Vector3(0.0, 1.05, -1.0), Vector3(4.4, 1.85, 1.55))
	_add_collision_box("IslandTableCollision", Vector3(0.0, 2.08, -1.0), Vector3(4.75, 0.22, 1.82))
	_add_collision_box("RearCabinetCollision", Vector3(0.0, 1.0, -5.45), Vector3(11.2, 1.95, 1.55))
	_add_collision_box("RearCounterCollision", Vector3(0.0, 2.06, -5.45), Vector3(11.2, 0.24, 1.78))
	_add_collision_box("BackBulkheadCollision", Vector3(0.0, 3.9, -6.8), Vector3(12.0, 7.8, 0.34))
	_add_collision_box("LeftBulkheadCollision", Vector3(-6.0, 3.9, 0.0), Vector3(0.34, 7.8, 14.0))
	_add_collision_box("RightBulkheadCollision", Vector3(6.0, 3.9, 0.0), Vector3(0.34, 7.8, 14.0))
	_add_collision_box("CeilingCollision", Vector3(0.0, 7.8, 0.0), Vector3(12.0, 0.30, 14.0))

func _add_collision_box(node_name: String, pos: Vector3, size: Vector3) -> void:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.collision_layer = 1
	body.collision_mask = 2
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	shape_node.shape = shape
	body.add_child(shape_node)
	add_child(body)

func _update_camera() -> void:
	var horizontal := cos(orbit_pitch) * orbit_distance
	camera.position = orbit_target + Vector3(sin(orbit_yaw) * horizontal, sin(orbit_pitch) * orbit_distance, cos(orbit_yaw) * horizontal)
	camera.look_at(orbit_target, Vector3.UP)
